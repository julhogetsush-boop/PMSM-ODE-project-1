# Presentation timing and speaker notes

Total suggested delivery: 600 seconds, followed by 3 minutes of Q&A.

This is an AI-assisted draft. Add the actual team metadata and rehearse individual explanations before submission.

## Slide 1: PMSM electrical dynamics

Suggested delivery: 30 seconds.

Introduce the custom deterministic ODE topic. The central question is how electrical rotation changes the numerical step needed to trust a voltage-driven current response. Explain that the report derives the model, proves problem-specific stability results, and tests those results independently. The illustrative benchmark and the user’s saved simulation are separate evidence sets.

Evidence: Project 1 Brief, supplied by the user, pp.1–4.

AI transparency: AI-assisted mathematical derivation, numerical code and writing. The report records independent checks. Student adoption, contribution records and oral explanations require actual student review.

## Slide 2: The voltage inputs drive two current states

Suggested delivery: 50 seconds.

State every assumption before presenting the ODE. Use the amplitude-invariant Park transform, a q-axis defined by negative sine, balanced sinusoidal phases and linear flux linkages. Electrical speed is prescribed. Thus this study models electrical current dynamics while the speed source exchanges mechanical power. It excludes saturation, PWM ripple and the speed-control loop. The parameter values form an illustrative salient-motor benchmark, not an identification of the existing Teknic motor.

Evidence: Report model derivation; code/model.py; code/results/summary.json.

AI transparency: AI-assisted mathematical derivation, numerical code and writing. The report records independent checks. Student adoption, contribution records and oral explanations require actual student review.

## Slide 3: The affine benchmark has an exact reference

Suggested delivery: 45 seconds.

Derive P-dot equals minus omega J P to explain the cross-coupling signs. With constant speed and voltage the model is affine. Subtract the unique equilibrium and use the matrix exponential. This case does not require a numerical integrator to obtain a solution. It provides a controlled benchmark for the library and for later variable-input or nonlinear models. The independent Radau solve uses relative tolerance 10^-12 and absolute tolerance 10^-14 A and agrees with the exact matrix solution to approximately 9.01e-13 A. A zero-speed RL special case gives another check.

Evidence: Report model and validation sections; code/model.py; code/test_numerics.py; code/results/summary.json.

AI transparency: AI-assisted mathematical derivation, numerical code and writing. The report records independent checks. Student adoption, contribution records and oral explanations require actual student review.

## Slide 4: Three methods expose accuracy and damping

Suggested delivery: 45 seconds.

Explain explicit Euler, classical RK4 and implicit Euler. The implementation owns the update logic and adaptive controller while NumPy and SciPy supply standard linear algebra and independent reference interfaces. Implicit Euler solves G(y)=y-y_n-h f(t_n+h,y)=0 with Newton. The residual is affine in this benchmark, so one exact linear correction solves it. That is useful verification but does not demonstrate robustness on a nonlinear saturated motor. Stability does not guarantee adequate phase or amplitude accuracy.

Evidence: Code/integrators.py and code/test_numerics.py; report methods section.

AI transparency: AI-assisted mathematical derivation, numerical code and writing. The report records independent checks. Student adoption, contribution records and oral explanations require actual student review.

## Slide 5: Electrical rotation limits explicit time steps

Suggested delivery: 60 seconds.

For the constant matrix, all modes decay asymptotically exactly when the amplification eigenvalues have modulus below one. Euler gives h less than (a+b)/(ab+omega squared), hence 0.800 milliseconds. The first RK4 crossing along the actual eigenvalue ray is 5.756 milliseconds. The overlay predicts the perturbation experiment on each side of the boundary. For a nonlinear or time-varying system this overlay becomes a local frozen-Jacobian diagnostic, not a complete proof. At high speed Euler scales as omega^-2 but RK4 scales as omega^-1. The conjugate eigenvalues have ratio one, so the baseline lacks a fast/slow eigenvalue split despite the oscillatory restriction.

Evidence: code/results/summary.json; code/results/stability_perturbations.csv; fig03_stability_regions.png; report stability derivation.

AI transparency: AI-assisted mathematical derivation, numerical code and writing. The report records independent checks. Student adoption, contribution records and oral explanations require actual student review.

## Slide 6: Stepwise decay is stricter than spectral stability

Suggested delivery: 60 seconds.

Define flux error z=D(i-i*) with D=diag(Ld,Lq). Its squared norm V has units of weber squared, not joules. The speed terms are skew-symmetric, so V-dot is negative. Implicit Euler preserves contraction with an additional nonnegative numerical dissipation term. Euler is more subtle: the maximum generalized eigenvalue yields an all-state one-step decay limit of 0.640 milliseconds. Between 0.640 and 0.800 milliseconds it remains asymptotically stable but a selected perturbation increases V on the first step. At .720 milliseconds, the spectral radius is .99247 but the first-step flux-error ratio is 1.01523. This falsifies the claim that stable eigenvalues guarantee monotone Lyapunov decay.

Evidence: Report flux-error theorem; code/results/euler_contractivity.csv; code/figures/fig11_contractivity.png.

AI transparency: AI-assisted mathematical derivation, numerical code and writing. The report records independent checks. Student adoption, contribution records and oral explanations require actual student review.

## Slide 7: Refinement recovers the predicted convergence orders

Suggested delivery: 55 seconds.

The norm is the maximum Euclidean current error at the numerical grid nodes, compared with the exact reference. Five halved steps run from 100 to 6.25 microseconds. Fit the four finer levels and disclose the range. The measured orders are approximately 1.016, 3.995 and 0.984, which agree with theory. The small deviations reflect finite-step effects and floating-point influence at the finest RK4 values. The shaded bands describe deterministic regression fits, not uncertainty in measured motor data.

Evidence: code/results/convergence.csv; code/results/summary.json; code/figures/fig02_convergence.png.

AI transparency: AI-assisted mathematical derivation, numerical code and writing. The report records independent checks. Student adoption, contribution records and oral explanations require actual student review.

## Slide 8: Adaptive RK4 meets its local acceptance rule

Suggested delivery: 55 seconds.

Step doubling compares one full RK4 step with two half steps. Divide their difference by fifteen to estimate the local error of the accepted fine result. Scale by atol plus rtol times the current magnitude, reject if the scaled norm exceeds one, and update h with a safety factor and exponent one fifth. With atol 10^-7 A and rtol 10^-7, the run accepts 99 steps and rejects two. The maximum accepted local ratio is 0.783, but the maximum global current error is 6.24 microamperes. A local tolerance does not promise the same global error. The final short step lands exactly at 50 milliseconds.

Evidence: code/results/adaptive_selected_steps.csv; code/results/adaptive_tolerances.csv; code/integrators.py.

AI transparency: AI-assisted mathematical derivation, numerical code and writing. The report records independent checks. Student adoption, contribution records and oral explanations require actual student review.

## Slide 9: A voltage step produces an oscillatory torque transient

Suggested delivery: 45 seconds.

The fixed-speed electrical system tends to 4.8 amperes on d and 0.8 amperes on q. Saliency contributes to torque. The reference reaches a positive torque peak near 1.333 newton metres at 2.975 milliseconds, then a negative minimum near -0.162 newton metres. These are illustrative model predictions. At equilibrium the electrical power is 60 watts, copper loss is 17.76 watts and mechanical conversion is 42.24 watts. This balance tests the sign convention and reminds us that fixed speed still permits power exchange. A model-RHS residual alone would be only an algebraic check.

Evidence: code/results/baseline_reference.csv; code/results/summary.json; report physical power balance.

AI transparency: AI-assisted mathematical derivation, numerical code and writing. The report records independent checks. Student adoption, contribution records and oral explanations require actual student review.

## Slide 10: The saved-model replay exposes a persistent mismatch

Suggested delivery: 45 seconds.

Now change evidence sets explicitly. The user’s previously saved Simulink run represents a Teknic motor with R .36 ohm, Ld=Lq=.2 millihenry, flux .0063954 weber and four pole pairs. This is not hardware data, and the original model was not rerun. Replay the logged voltages and speed from the initial current without resetting it. Refining RK4 makes the replay converge, but the discrepancy from saved currents remains roughly .402 amperes in maximum vector norm. The h/8 versus h/16 difference is only 2.78e-10 amperes. We therefore cannot attribute the plateau to RK4 truncation. Audit signal timing, voltage location, angle conventions and omitted plant effects before claiming empirical validation.

Evidence: code/results/existing_model_summary.json; code/data/existing_model_metadata.json; code/existing_model_check.py.

AI transparency: AI-assisted mathematical derivation, numerical code and writing. The report records independent checks. Student adoption, contribution records and oral explanations require actual student review.

## Slide 11: Hardware data would test the physical model

Suggested delivery: 60 seconds.

Hardware acquisition is not required to establish numerical correctness in this project. The present replay mismatch should first trigger a signal audit. Verify angle direction and timing, peak versus RMS scaling, motor-terminal voltage versus controller commands, and whether board resistance is already removed. Then, subject to laboratory supervision and current limits, collect time-synchronised three-phase voltage and current, electrical angle and speed, DC-bus voltage, temperature and the input command. Begin with small perturbations at a controlled low-speed operating point. Fit parameters on one run and test predictions on a separate run. Log calibration, sampling and uncertainty. Real data would validate the model assumptions and parameter values, not repair a numerically wrong method.

Evidence: Report hardware-validation recommendation and existing-model limitations.

AI transparency: AI-assisted mathematical derivation, numerical code and writing. The report records independent checks. Student adoption, contribution records and oral explanations require actual student review.

## Slide 12: Validated numerics separate solver error from model error

Suggested delivery: 50 seconds.

Conclude with the original question. Electrical rotation explains the explicit stability restriction even without a fast/slow eigenvalue split. The three schemes recover their expected orders, and the exact plus Radau checks establish numerical correctness in the benchmark. The new flux-error result distinguishes monotone decay from eventual decay. Adaptivity controls a local estimate rather than certifying a global error. The saved-model mismatch survives numerical refinement, so the next step is an evidence-driven signal audit before hardware validation. For questions, be ready to derive the cross-coupling signs, defend why numerical methods matter when an exact benchmark exists, explain affine Newton, and distinguish the flux Lyapunov function from physical magnetic energy.

Evidence: Report conclusions, AI Transparency Log and all reproduced experiment outputs.

AI transparency: AI-assisted mathematical derivation, numerical code and writing. The report records independent checks. Student adoption, contribution records and oral explanations require actual student review.
