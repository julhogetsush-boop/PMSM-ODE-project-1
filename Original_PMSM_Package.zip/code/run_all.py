"""Regenerate every reported number and figure: python code/run_all.py."""
from pathlib import Path
from dataclasses import asdict
import csv
import io
import json
import platform
import time
import unittest
import numpy as np
import scipy
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
from scipy.linalg import eigh
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
from model import PMSM
from integrators import (solve_fixed, solve_adaptive_rk4, finite_difference_jacobian,
                         implicit_euler_step)

BASE = Path(__file__).resolve().parent
FIG = BASE / "figures"
RES = BASE / "results"
METHODS = ("euler", "rk4", "implicit_euler")
LABELS = {"euler": "Explicit Euler", "rk4": "RK4", "implicit_euler": "Implicit Euler"}
COLORS = {"euler": "#0072B2", "rk4": "#D55E00", "implicit_euler": "#009E73"}
STYLES = {"euler": "--", "rk4": "-.", "implicit_euler": ":"}
plt.rcParams.update({"font.size": 10, "axes.labelsize": 11, "axes.titlesize": 11,
                     "legend.fontsize": 9, "figure.dpi": 110, "savefig.dpi": 240,
                     "axes.grid": True, "grid.alpha": .2, "axes.spines.top": False,
                     "axes.spines.right": False, "lines.linewidth": 1.6})


def save(fig, name):
    fig.savefig(FIG / (name + ".png"), bbox_inches="tight")
    fig.savefig(FIG / (name + ".pdf"), bbox_inches="tight")
    plt.close(fig)


def table(name, rows):
    with (RES / name).open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def stability_function(z, method):
    if method == "euler":
        return 1 + z
    if method == "rk4":
        return 1 + z + z*z/2 + z**3/6 + z**4/24
    return 1 / (1 - z)


def step_limits(m):
    eig = np.linalg.eigvals(m.A)
    he = min(-2 * z.real / abs(z)**2 for z in eig)
    def boundary(h):
        return max(abs(stability_function(h*z, "rk4")) for z in eig) - 1
    # Exclude the trivial boundary h=0 and bracket the first positive exit.
    hs = np.geomspace(1e-7/max(1, max(abs(eig))), 10/max(abs(eig)), 400)
    for lo, hi in zip(hs[:-1], hs[1:]):
        if boundary(lo) < 0 and boundary(hi) >= 0:
            return float(he), float(brentq(boundary, lo, hi, xtol=1e-15))
    raise RuntimeError("could not bracket RK4 stability boundary")


def convergence(m):
    rows, fits = [], {}
    fig, axes = plt.subplots(1, 3, figsize=(11.2, 3.8), layout="constrained")
    for ax, method in zip(axes, METHODS):
        mr = []
        for n in (500, 1000, 2000, 4000, 8000):
            s = solve_fixed(m.rhs, (0, .05), [0,0], n, method, m.jac)
            err = np.linalg.norm(s.y-m.exact(s.t), axis=1)
            row = {"method": method, "steps": n, "h_s": .05/n,
                   "max_current_error_A": float(max(err)), "endpoint_error_A": float(err[-1]),
                   "rhs_evaluations": s.stats["rhs_evaluations"]}
            rows.append(row)
            mr.append(row)
        h = np.array([r["h_s"] for r in mr])
        err = np.array([r["max_current_error_A"] for r in mr])
        # Fit the finest four points to reduce pre-asymptotic bias.
        coef, cov = np.polyfit(np.log(h[1:]), np.log(err[1:]), 1, cov=True)
        fits[method] = {"order": float(coef[0]), "standard_error": float(np.sqrt(cov[0,0])),
                        "fit_h_s": h[1:].tolist(), "intercept": float(coef[1])}
        lx = np.linspace(np.log(min(h)), np.log(max(h)), 100)
        line = coef[0]*lx+coef[1]
        se = np.sqrt(np.maximum(0,cov[1,1]+2*lx*cov[0,1]+lx*lx*cov[0,0]))
        ax.loglog(h,err,"o-",color=COLORS[method],label="Measured error")
        ax.loglog(np.exp(lx),np.exp(line),"k--",lw=1,label=f"Fit: p={coef[0]:.4f}")
        ax.fill_between(np.exp(lx),np.exp(line-1.96*se),np.exp(line+1.96*se),
                        color="gray",alpha=.3,label="95% fit band")
        expected = 4 if method == "rk4" else 1
        theoretical = err[-1]*(np.exp(lx)/h[-1])**expected*1.7
        ax.loglog(np.exp(lx),theoretical,":",color="#CC79A7",label=f"Theoretical order {expected}")
        ax.set(xlabel="Step size h [s]",ylabel="Maximum current error [A]",
               title=f"{LABELS[method]} recovers order {expected}")
        ax.legend(fontsize=7.8)
    save(fig,"fig02_convergence")
    table("convergence.csv",rows)
    return {"rows":rows,"fits":fits}


def stability_experiments(m):
    he, hr = step_limits(m)
    eig = np.linalg.eigvals(m.A)
    xx, yy = np.meshgrid(np.linspace(-4,2,700),np.linspace(-4,4,800))
    z = xx+1j*yy
    fig, axes = plt.subplots(1,3,figsize=(11.2,4.1),layout="constrained")
    for ax, method in zip(axes, METHODS):
        with np.errstate(divide="ignore",invalid="ignore"):
            amp = abs(stability_function(z,method))
        ax.contourf(xx,yy,amp,levels=[0,1],colors=["#D8EAF4"])
        ax.contour(xx,yy,amp,levels=[1],colors=[COLORS[method]],linewidths=1.5)
        for h, marker, label in ((.8*he,"o","0.8 h_E"),(1.2*he,"x","1.2 h_E"),
                                  (.8*hr,"s","0.8 h_RK4"),(1.2*hr,"+","1.2 h_RK4")):
            ax.plot((h*eig).real,(h*eig).imag,marker,ms=6,label=label,linestyle="none")
        ax.axhline(0,color="gray",lw=.6)
        ax.axvline(0,color="gray",lw=.6)
        ax.set(xlim=(-4,2),ylim=(-4,4),aspect="equal",xlabel="Re(hλ) [dimensionless]",
               ylabel="Im(hλ) [dimensionless]",title=LABELS[method]+": shaded |R| ≤ 1")
        ax.legend(fontsize=7,loc="lower left")
    save(fig,"fig03_stability_regions")
    fig, axes = plt.subplots(1,2,figsize=(10,3.8),layout="constrained")
    rows=[]
    for ax, method, hc in zip(axes,("euler","rk4"),(he,hr)):
        t_dense=np.linspace(0,.1,1001)
        e_exact=np.array([m.exact(t,(1,0))-m.exact(t,(0,0)) for t in t_dense])
        exact_norm=np.linalg.norm(e_exact*np.array([m.ld,m.lq]),axis=1)/m.ld
        ax.semilogy(t_dense*1e3,exact_norm,"k-",label="Exact perturbation")
        for factor, style in ((.8,"--"),(1.2,":")):
            n=max(1,int(round(.1/(factor*hc))))
            h=.1/n
            s=solve_fixed(lambda t,e:m.A@e,(0,.1),[1,0],n,method,lambda t,e:m.A)
            norm=np.linalg.norm(s.y*np.array([m.ld,m.lq]),axis=1)/m.ld
            rho=max(abs(stability_function(h*eig,method)))
            rows.append({"method":method,"requested_factor":factor,"steps":n,"h_s":h,
                         "h_over_hcrit":h/hc,"spectral_amplification":float(rho),
                         "final_flux_norm_ratio":float(norm[-1])})
            ax.semilogy(s.t*1e3,norm,style,label=f"h/hcrit={h/hc:.3f}; ρ={rho:.3f}")
        ax.set(xlabel="Time [ms]",ylabel="Flux perturbation / initial norm [−]",
               title=f"{LABELS[method]}: threshold predicts growth")
        ax.legend(fontsize=8)
    save(fig,"fig04_stability_test")
    table("stability_perturbations.csv",rows)
    return {"euler_hcrit_s":he,"rk4_hcrit_s":hr,"perturbations":rows}


def adaptivity(m):
    rows=[]
    chosen=None
    for tol in (1e-3,1e-4,1e-5,1e-6,1e-7,1e-8,1e-9):
        s=solve_adaptive_rk4(m.rhs,(0,.05),[0,0],atol=tol,rtol=tol,h0=.005)
        ref=m.exact(s.t)
        difference=s.y-ref
        global_scaled=np.sqrt(np.mean((difference/(tol+tol*np.abs(ref)))**2,axis=1))
        err=np.linalg.norm(difference,axis=1)
        hs=s.stats["accepted_h"]
        rows.append({"atol_A":tol,"rtol":tol,"accepted_steps":s.stats["steps"],
                     "rejected_steps":s.stats["rejections"],"rhs_evaluations":s.stats["rhs_evaluations"],
                     "h_min_s":min(hs),"h_max_s":max(hs),
                     "max_local_scaled_error":max(s.stats["error_ratios"]),
                     "max_current_error_A":float(max(err)),"endpoint_error_A":float(err[-1]),
                     "max_global_scaled_error":float(max(global_scaled))})
        if tol==1e-7:
            chosen=s
    s=chosen
    engineering_target=1e-5
    selected_error=float(np.max(np.linalg.norm(s.y-m.exact(s.t),axis=1)))
    if selected_error>engineering_target:
        raise RuntimeError("selected adaptive run did not meet independently checked global target")
    measured_local=[]
    for n,h in enumerate(s.stats["accepted_h"]):
        exact_next=m.exact(h,s.y[n])
        scale=1e-7+1e-7*np.maximum(abs(s.y[n]),abs(s.y[n+1]))
        measured_local.append(float(np.sqrt(np.mean(((s.y[n+1]-exact_next)/scale)**2))))
    fig,axes=plt.subplots(3,1,figsize=(8.5,7),layout="constrained",sharex=True)
    axes[0].step(s.t[1:]*1e3,np.array(s.stats["accepted_h"])*1e3,where="post",label="Accepted step size")
    for trial in s.stats["rejected_trials"]:
        axes[0].plot(trial["t"]*1e3,trial["h"]*1e3,"x",color="#D55E00",ms=6)
    axes[0].plot([],[],"x",color="#D55E00",label="Rejected trial")
    axes[0].set(ylabel="Step size [ms]",title="Adaptive RK4 changes h as the transient decays")
    axes[0].legend()
    axes[1].plot(s.t[1:]*1e3,s.stats["error_ratios"],"o-",ms=2.5,label="Scaled local error estimate")
    axes[1].plot(s.t[1:]*1e3,measured_local,":",color="#009E73",label="Exact one-step local error")
    axes[1].axhline(1,color="#D55E00",ls="--",label="Acceptance limit")
    axes[1].set(ylabel="Local error ratio [−]")
    axes[1].legend()
    error=np.linalg.norm(s.y-m.exact(s.t),axis=1)
    axes[2].semilogy(s.t[1:]*1e3,error[1:],label="Global current error at accepted nodes")
    axes[2].set(xlabel="Time [ms]",ylabel="Current error [A]")
    axes[2].legend()
    save(fig,"fig05_adaptivity")
    fig,axes=plt.subplots(1,2,figsize=(10,3.8),layout="constrained")
    tol=np.array([r["atol_A"] for r in rows])
    err=np.array([r["max_current_error_A"] for r in rows])
    axes[0].loglog(tol,err,"o-",label="Maximum global current error")
    axes[0].loglog(tol,err[-1]*(tol/tol[-1])**.8,"k--",label="Reference slope 4/5")
    axes[0].loglog(tol,tol,":",color="#D55E00",label="atol (not a global bound)")
    axes[0].set(xlabel="Tolerance ε: atol = ε A, rtol = ε",ylabel="Maximum current error [A]",
                title="Global error decreases; local tolerance is not a bound")
    axes[0].legend(fontsize=8)
    axes[1].loglog(tol,[r["rhs_evaluations"] for r in rows],"o-",label="RHS evaluations")
    axes[1].set(xlabel="Tolerance ε [−]",ylabel="RHS evaluations [count]",
                title="Tighter tolerance costs more evaluations")
    axes[1].legend()
    save(fig,"fig06_tolerance_sweep")
    table("adaptive_tolerances.csv",rows)
    table("adaptive_selected_steps.csv",[{"t_s":float(t),"h_s":h,"local_error_ratio":r,"exact_local_error_ratio":a}
          for t,h,r,a in zip(s.t[1:],s.stats["accepted_h"],s.stats["error_ratios"],measured_local)])
    estimator_ratios=np.array(measured_local)/np.array(s.stats["error_ratios"])
    return {"rows":rows,"selected_tolerance":1e-7,"selected_stats":s.stats,
            "verified_global_engineering_target_A":engineering_target,
            "verified_global_engineering_target_passed":selected_error<=engineering_target,
            "exact_local_scaled_error_max":max(measured_local),
            "exact_to_estimated_local_error_ratio_min":float(min(estimator_ratios)),
            "exact_to_estimated_local_error_ratio_max":float(max(estimator_ratios))}


def contractivity(m):
    D=np.diag([m.ld,m.lq])
    B=D@m.A@np.diag([1/m.ld,1/m.lq])
    C=-(B+B.T)
    h_contract=float(min(eigh(C,B.T@B,eigvals_only=True)))
    h=.00072
    M=np.eye(2)+h*B
    vals,vecs=np.linalg.eigh(M.T@M)
    x0=.001*vecs[:,-1]
    e0=x0/np.array([m.ld,m.lq])
    s=solve_fixed(lambda t,e:m.A@e,(0,30*h),e0,30,"euler")
    exact=np.array([m.exact(t,e0)-m.exact(t,[0,0]) for t in s.t])
    exact_V=np.sum((exact*np.array([m.ld,m.lq]))**2,axis=1)/np.dot(x0,x0)
    numerical_V=np.sum((s.y*np.array([m.ld,m.lq]))**2,axis=1)/np.dot(x0,x0)
    fig,axes=plt.subplots(1,2,figsize=(10,3.8),layout="constrained")
    for ax in axes:
        ax.plot(s.t*1e3,numerical_V,"o--",ms=3,label="Euler at h=0.72 ms")
        ax.plot(s.t*1e3,exact_V,"k-",label="Exact flux-error decay")
        ax.axhline(1,color="gray",ls=":",lw=1)
        ax.set(xlabel="Time [ms]",ylabel="V / V(0) [−]")
        ax.legend(fontsize=8)
    axes[0].set(title="A stable Euler step can increase the flux-error norm",xlim=(0,3*h*1e3))
    axes[1].set(title="The same perturbation still decays asymptotically")
    save(fig,"fig11_contractivity")
    table("euler_contractivity.csv",[{"t_s":float(t),"euler_V_ratio":float(v),"exact_V_ratio":float(e)}
          for t,v,e in zip(s.t,numerical_V,exact_V)])
    return {"all_state_monotonic_flux_hmax_s":h_contract,"experiment_h_s":h,
            "initial_current_perturbation_A":e0.tolist(),
            "one_step_V_ratio":float(numerical_V[1]),
            "spectral_amplification":float(max(abs(np.linalg.eigvals(M)))),
            "maximum_one_step_V_ratio":float(max(vals))}


def energy(m,t,ref):
    pin,pcu,pmech,dw=m.power_terms(ref)
    residual=pin-pcu-pmech-dw
    V=m.flux_error_energy(ref)
    s=solve_fixed(m.rhs,(0,.05),[0,0],8,"implicit_euler",m.jac)
    x=(s.y-m.steady)*np.array([m.ld,m.lq])
    vn=.5*np.sum(x*x,axis=1)
    identity=np.diff(vn)+np.diff(s.t)*m.resistance*(x[1:,0]**2/m.ld+x[1:,1]**2/m.lq)+.5*np.sum(np.diff(x,axis=0)**2,axis=1)
    fig,axes=plt.subplots(1,2,figsize=(10,3.8),layout="constrained")
    axes[0].semilogy(t*1e3,V/V[0],"k-",label="Exact flux-error V/V(0)")
    axes[0].semilogy(t*1e3,np.exp(-2*m.resistance/max(m.ld,m.lq)*t),"--",label="Proved exponential upper bound")
    axes[0].semilogy(s.t*1e3,vn/vn[0],"o:",color=COLORS["implicit_euler"],label="Implicit Euler, h=6.25 ms")
    axes[0].set(xlabel="Time [ms]",ylabel="Normalized flux-error norm squared [−]",
                title="Flux error contracts, including coarse implicit steps")
    axes[0].legend(fontsize=8)
    for val,label,style in ((pin,"Electrical input","-"),(pcu,"Copper loss","--"),
                            (pmech,"Mechanical power","-."),(dw,"Stored-energy rate",":")):
        axes[1].plot(t*1e3,val,style,label=label)
    axes[1].set(xlabel="Time [ms]",ylabel="Power [W]",title="Physical power balance includes mechanical transfer")
    axes[1].legend(fontsize=8)
    save(fig,"fig07_energy")
    return {"max_physical_power_residual_W":float(max(abs(residual))),
            "max_implicit_discrete_identity_residual_Wb2":float(max(abs(identity))),
            "initial_flux_error_V_Wb2":float(V[0]),"initial_magnetic_energy_J":float(m.magnetic_energy(ref[0])),
            "final_magnetic_energy_J":float(m.magnetic_energy(ref[-1])),
            "bound_decay_rate_per_s":2*m.resistance/max(m.ld,m.lq),
            "coarse_implicit_h_s":.05/8,"coarse_implicit_newton_stats":s.stats}


def speeds():
    rows=[]
    t=np.linspace(0,.05,2001)
    fig,axes=plt.subplots(1,2,figsize=(10,3.8),layout="constrained")
    for omega,style in ((0,"-"),(500,"--"),(1500,"-.")):
        m=PMSM(omega_e=omega,uq=omega*.08+10)
        ref=m.exact(t)
        he,hr=step_limits(m)
        lam=np.linalg.eigvals(m.A)
        rows.append({"omega_e_rad_s":omega,"uq_V":m.uq,"steady_id_A":float(m.steady[0]),
                     "steady_iq_A":float(m.steady[1]),"steady_torque_Nm":float(m.torque(m.steady)),
                     "euler_hcrit_s":he,"rk4_hcrit_s":hr,"eigenvalue_modulus_ratio":float(max(abs(lam))/min(abs(lam)))})
        for j,ax in enumerate(axes):
            ax.plot(t*1e3,ref[:,j],style,label=f"ωe={omega} rad/s; uq={m.uq:.0f} V")
            ax.set(xlabel="Time [ms]",ylabel=f"{'d' if j==0 else 'q'}-axis current [A]",
                   title=f"Speed changes the {'d' if j==0 else 'q'}-axis transient")
            ax.legend(fontsize=8)
    save(fig,"fig08_speed_comparison")
    values=[]
    for omega in np.geomspace(20,20000,120):
        m=PMSM(omega_e=float(omega),uq=omega*.08+10)
        he,hr=step_limits(m)
        values.append({"omega_e_rad_s":float(omega),"euler_hcrit_s":he,"rk4_hcrit_s":hr})
    ws=np.array([r["omega_e_rad_s"] for r in values])
    e=np.array([r["euler_hcrit_s"] for r in values])
    r=np.array([r["rk4_hcrit_s"] for r in values])
    fig,ax=plt.subplots(figsize=(7.5,4.5),layout="constrained")
    ax.loglog(ws,e,label="Explicit Euler",color=COLORS["euler"])
    ax.loglog(ws,r,"--",label="RK4",color=COLORS["rk4"])
    wh=ws[ws>=2000]
    ax.loglog(wh,208.333333333/wh**2,":",color=COLORS["euler"],label="Euler asymptote: 2α/ωe²")
    ax.loglog(wh,np.sqrt(8)/wh,":",color=COLORS["rk4"],label="RK4 asymptote: √8/ωe")
    ax.set(xlabel="Electrical angular speed ωe [rad/s]",ylabel="Maximum stable step [s]",
           title="High speed penalizes Euler quadratically and RK4 linearly")
    ax.legend()
    save(fig,"fig09_speed_restrictions")
    table("speed_comparison.csv",rows)
    table("speed_stability_limits.csv",values)
    return {"comparison":rows,"restriction_sweep":values}


def sensitivity():
    m=PMSM()
    base=np.array([*m.steady,m.torque(m.steady)])
    rows=[]
    for param in ("resistance","ld","lq","flux_pm"):
        kwargs=asdict(m)
        original=kwargs[param]
        outputs=[]
        for factor in (.99,1.01):
            kwargs[param]=original*factor
            altered=PMSM(**kwargs)
            outputs.append(np.array([*altered.steady,altered.torque(altered.steady)]))
        elastic=(outputs[1]-outputs[0])/(.02*base)
        rows.append({"parameter":param,"id_elasticity":float(elastic[0]),
                     "iq_elasticity":float(elastic[1]),"torque_elasticity":float(elastic[2])})
    fig,ax=plt.subplots(figsize=(7.5,4.3),layout="constrained")
    x=np.arange(4)
    for j,(key,label) in enumerate((("id_elasticity","Steady id"),("iq_elasticity","Steady iq"),
                                   ("torque_elasticity","Steady torque"))):
        ax.bar(x+(j-1)*.24,[r[key] for r in rows],width=.23,label=label)
    ax.axhline(0,color="black",lw=.7)
    ax.set(xticks=x,xticklabels=["Rs","Ld","Lq","ψf"],xlabel="Perturbed model parameter",
           ylabel="Relative output / relative parameter [−]",
           title="PM flux uncertainty strongly affects the operating point")
    ax.legend()
    save(fig,"fig10_sensitivity")
    table("steady_parameter_sensitivity.csv",rows)
    return {"relative_central_difference_step":.01,"fixed_voltage_and_speed":True,"rows":rows}


def main():
    started=time.perf_counter()
    FIG.mkdir(exist_ok=True)
    RES.mkdir(exist_ok=True)
    test_log=io.StringIO()
    suite=unittest.defaultTestLoader.discover(str(BASE),pattern="test_numerics.py")
    result=unittest.TextTestRunner(stream=test_log,verbosity=2).run(suite)
    (RES/"test_results.txt").write_text(test_log.getvalue(),encoding="utf-8")
    print(test_log.getvalue())
    if not result.wasSuccessful():
        raise RuntimeError("numerical tests failed; figures not released")
    m=PMSM()
    t=np.linspace(0,.05,2001)
    ref=m.exact(t)
    oracle=solve_ivp(m.rhs,(0,.05),[0,0],method="Radau",jac=m.jac,
                     rtol=1e-12,atol=1e-14,dense_output=True)
    if not oracle.success:
        raise RuntimeError(oracle.message)
    oracle_err=float(np.max(np.linalg.norm(oracle.sol(t).T-ref,axis=1)))
    if oracle_err>1e-9:
        raise RuntimeError("independent reference check failed")
    lam=np.linalg.eigvals(m.A)
    torque=m.torque(ref)
    fig,axes=plt.subplots(2,2,figsize=(10,6.5),layout="constrained")
    for j,ax in enumerate(axes[0]):
        ax.plot(t*1e3,ref[:,j],"k-",lw=2,label="Matrix-exponential reference")
        for method in METHODS:
            s=solve_fixed(m.rhs,(0,.05),[0,0],100,method,m.jac)
            ax.plot(s.t*1e3,s.y[:,j],STYLES[method],color=COLORS[method],label=LABELS[method])
        ax.axhline(m.steady[j],color="gray",lw=.8,ls="--")
        ax.set(xlabel="Time [ms]",ylabel=f"{'d' if j==0 else 'q'}-axis current [A]",
               title="Stable methods can still distort the transient")
        ax.legend(fontsize=7)
    axes[1,0].plot(t*1e3,torque,"k-",label="Exact electromagnetic torque")
    axes[1,0].axhline(m.torque(m.steady),color="#D55E00",ls="--",label="Steady torque")
    axes[1,0].set(xlabel="Time [ms]",ylabel="Torque [N m]",title="Electrical ringing produces a torque transient")
    axes[1,0].legend(fontsize=8)
    axes[1,1].plot(ref[:,0],ref[:,1],"k-",label="Exact current trajectory")
    axes[1,1].plot(0,0,"o",color="#0072B2",label="Initial current")
    axes[1,1].plot(*m.steady,"x",color="#D55E00",ms=8,label="Equilibrium")
    axes[1,1].set(xlabel="d-axis current [A]",ylabel="q-axis current [A]",
                  title="The current trajectory spirals toward equilibrium")
    axes[1,1].legend(fontsize=8)
    save(fig,"fig01_transient")
    table("baseline_reference.csv",[{"t_s":float(ti),"id_A":float(yi[0]),"iq_A":float(yi[1]),
          "torque_Nm":float(tq),"magnetic_energy_J":float(wm)} for ti,yi,tq,wm in zip(t,ref,torque,m.magnetic_energy(ref))])
    Jfd=finite_difference_jacobian(m.rhs,0,np.array([2.,-1.]))
    residual_jac_fd=finite_difference_jacobian(lambda ti,w:w-np.array([2.,-1.])-.001*m.rhs(ti,w),.001,np.array([2.,-1.]))
    _,newton_diag=implicit_euler_step(lambda ti,w:-w*w,lambda ti,w:np.diag(-2*w),
                                     0,np.array([1.]),1,atol=1e-14,rtol=0)
    # Settling is assessed against a 2% flux-error envelope, sampled every 25 us.
    ratio=np.sqrt(m.flux_error_energy(ref)/m.flux_error_energy(ref[0]))
    outside=np.where(ratio>.02)[0]
    settling=float(t[outside[-1]+1]) if outside.size and outside[-1]+1<t.size else None
    summary={"parameters":asdict(m),
             "baseline":{"A_per_s":m.A.tolist(),"b_A_per_s":m.b.tolist(),"steady_current_A":m.steady.tolist(),
                          "final_current_A":ref[-1].tolist(),"steady_torque_Nm":float(m.torque(m.steady)),
                          "eigenvalues_per_s":[{"real":float(z.real),"imag":float(z.imag)} for z in lam],
                          "eigenvalue_modulus_ratio":float(max(abs(lam))/min(abs(lam))),
                          "decay_time_s":float(-1/lam[0].real),"oscillation_period_s":float(2*np.pi/abs(lam[0].imag)),
                          "max_torque_Nm":float(max(torque)),"max_torque_time_s":float(t[np.argmax(torque)]),
                          "min_torque_Nm":float(min(torque)),"min_torque_time_s":float(t[np.argmin(torque)]),
                          "flux_2percent_settling_time_s_grid_estimate":settling},
             "validation":{"matrix_exponential_vs_Radau_max_error_A":oracle_err,"Radau_rtol":1e-12,
                           "Radau_atol_A":1e-14,"Radau_rhs_evaluations":oracle.nfev,
                           "RHS_jacobian_fd_max_difference_per_s":float(np.max(abs(Jfd-m.A))),
                           "implicit_residual_jacobian_fd_max_difference":float(np.max(abs(residual_jac_fd-(np.eye(2)-.001*m.A)))),
                           "nonlinear_newton_scalar_diagnostics":newton_diag},
             "tests":{"run":result.testsRun,"failures":len(result.failures),"errors":len(result.errors)},
             "environment":{"python":platform.python_version(),"numpy":np.__version__,
                            "scipy":scipy.__version__,"matplotlib":matplotlib.__version__}}
    for key,func in (("convergence",lambda:convergence(m)),("stability",lambda:stability_experiments(m)),
                     ("adaptive",lambda:adaptivity(m)),("energy",lambda:energy(m,t,ref)),
                     ("speed_sweep",speeds),("sensitivity",sensitivity),("euler_contractivity",lambda:contractivity(m))):
        print("Generating",key,flush=True)
        summary[key]=func()
    fig,ax=plt.subplots(figsize=(5.5,4.5),layout="constrained")
    ax.plot(ref[:,0],ref[:,1],color=".8",lw=1,label="Complete reference trajectory")
    line,=ax.plot([],[],color="#0072B2",label="Elapsed trajectory")
    point,=ax.plot([],[],"o",color="#D55E00")
    ax.plot(*m.steady,"kx",label="Equilibrium")
    label=ax.text(.04,.95,"",transform=ax.transAxes,va="top")
    ax.set(xlabel="d-axis current [A]",ylabel="q-axis current [A]",title="A damped electrical transient approaches equilibrium")
    ax.legend(loc="lower right",fontsize=7)
    def update(frame):
        n=min(len(t)-1,frame*20)
        line.set_data(ref[:n+1,0],ref[:n+1,1])
        point.set_data([ref[n,0]],[ref[n,1]])
        label.set_text(f"t = {t[n]*1000:.1f} ms")
        return line,point,label
    anim=FuncAnimation(fig,update,frames=101,interval=50,blit=True)
    anim.save(FIG/"dq_phase.gif",writer=PillowWriter(fps=20),dpi=120)
    plt.close(fig)
    replay=BASE/"existing_model_check.py"
    if replay.exists():
        import subprocess,sys
        subprocess.run([sys.executable,str(replay)],check=True,cwd=BASE)
    summary["runtime_seconds"]=time.perf_counter()-started
    (RES/"summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    if (BASE/"build_report_results.py").exists():
        from build_report_results import main as build_report_results
        build_report_results()
    print(json.dumps({"baseline":summary["baseline"],"validation":summary["validation"],
                      "convergence_fits":summary["convergence"]["fits"],
                      "adaptive_rows":summary["adaptive"]["rows"],"energy":summary["energy"],
                      "tests":summary["tests"],"runtime_seconds":summary["runtime_seconds"]},indent=2))


if __name__=="__main__":
    main()
