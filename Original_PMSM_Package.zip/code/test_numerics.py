"""Meaningful solver/model checks, executable with standard-library unittest."""
import unittest
import numpy as np
from integrators import (solve_fixed, solve_adaptive_rk4, implicit_euler_step,
                         finite_difference_jacobian, NewtonFailure)
from model import PMSM


class NumericalTests(unittest.TestCase):
    def test_zero_speed_analytic_case(self):
        m = PMSM(omega_e=0, uq=10)
        t = np.linspace(0, .05, 21)
        expected = np.column_stack((np.zeros(t.size),
                    20 * (1 - np.exp(-m.resistance * t / m.lq))))
        np.testing.assert_allclose(m.exact(t), expected, atol=1e-13)

    def test_linear_reference_and_fixed_shapes(self):
        m = PMSM()
        s = solve_fixed(m.rhs, (0, .05), [0, 0], 1000)
        self.assertEqual(s.y.shape, (1001, 2))
        self.assertEqual(s.t[-1], .05)
        self.assertLess(np.max(np.linalg.norm(s.y - m.exact(s.t), axis=1)), 1e-7)

    def test_expected_orders_on_nonautonomous_equation(self):
        # y'=t y tests RK stage times as well as state arguments.
        f = lambda t, y: t * y
        j = lambda t, y: np.array([[t]])
        for method, expected in (("euler", 1), ("rk4", 4), ("implicit_euler", 1)):
            err = [abs(solve_fixed(f, (0, 1), [1], n, method, j).y[-1, 0] - np.exp(.5))
                   for n in (40, 80)]
            order = np.log2(err[0] / err[1])
            self.assertAlmostEqual(order, expected, delta=.08)

    def test_newton_nonlinear_iterations_and_quadratic_convergence(self):
        f = lambda t, y: -y * y
        jac = lambda t, y: np.diag(-2 * y)
        root = (np.sqrt(5) - 1) / 2
        result, diag = implicit_euler_step(f, jac, 0, np.array([1.]), 1., atol=1e-14, rtol=0)
        self.assertAlmostEqual(result[0], root, places=13)
        self.assertGreaterEqual(diag["iterations"], 4)
        residuals = np.array(diag["residuals"])
        ratios = residuals[1:-1] / residuals[:-2] ** 2
        self.assertTrue(np.all((ratios > .1) & (ratios < .25)))
        fd, _ = implicit_euler_step(f, None, 0, np.array([1.]), 1.)
        np.testing.assert_allclose(fd, result, atol=1e-10)

    def test_newton_reports_failure(self):
        with self.assertRaises(NewtonFailure):
            implicit_euler_step(lambda t, y: -y*y, lambda t, y: np.diag(-2*y),
                                0, np.array([1.]), 1., max_iter=1)
        with self.assertRaises(NewtonFailure):
            implicit_euler_step(lambda t, y: y, lambda t, y: np.eye(1),
                                0, np.array([1.]), 1.)

    def test_newton_damping_is_used_successfully(self):
        # F(w)=exp(w)-2 from a poor initial guess: a full first step overshoots.
        f = lambda t, y: y+5-np.exp(y)
        jac = lambda t, y: np.diag(1-np.exp(y))
        value, diag = implicit_euler_step(f, jac, 0, np.array([-3.]), 1.)
        self.assertAlmostEqual(value[0], np.log(2), places=10)
        self.assertLess(min(diag["damping"]), 1.)

    def test_adaptive_rejection_variation_and_accuracy(self):
        m = PMSM()
        s = solve_adaptive_rk4(m.rhs, (0, .05), [0, 0], atol=1e-8, rtol=1e-8, h0=.01)
        self.assertEqual(s.t[-1], .05)
        self.assertGreater(s.stats["rejections"], 0)
        self.assertGreater(max(s.stats["accepted_h"]) / min(s.stats["accepted_h"]), 1.5)
        self.assertLessEqual(max(s.stats["error_ratios"]), 1.)
        self.assertLess(np.max(np.linalg.norm(s.y-m.exact(s.t), axis=1)), 2e-6)

    def test_adaptive_failure_and_validation(self):
        with self.assertRaises(RuntimeError):
            solve_adaptive_rk4(lambda t, y: -y, (0, 1), [1], max_steps=1, h0=.001)
        with self.assertRaises(ValueError):
            solve_adaptive_rk4(lambda t, y: -y, (0, 1), [1], atol=0)
        with self.assertRaises(ValueError):
            solve_fixed(lambda t, y: -y, (0, 1), [1], 0)
        with self.assertRaises(ValueError):
            solve_fixed(lambda t, y: -y, (1, 0), [1], 2)
        with self.assertRaises(ValueError):
            solve_fixed(lambda t, y: -y, (0, 1), [np.nan], 2)
        with self.assertRaises(ValueError):
            solve_fixed(lambda t, y: np.array([1, 2]), (0, 1), [1], 2)

    def test_jacobian_and_implicit_residual_jacobian(self):
        m = PMSM()
        y = np.array([2., -1.])
        np.testing.assert_allclose(finite_difference_jacobian(m.rhs, 0, y), m.A, rtol=1e-10)
        h = .001
        F = lambda t, w: w-y-h*m.rhs(t,w)
        np.testing.assert_allclose(finite_difference_jacobian(F, h, y), np.eye(2)-h*m.A, atol=1e-10)

    def test_physical_power_and_flux_lyapunov_identities(self):
        m = PMSM()
        y = np.array([[2., -1.], [5., 3.], [0., 0.]])
        pin, pcu, pmech, dw = m.power_terms(y)
        np.testing.assert_allclose(pin, pcu+pmech+dw, atol=2e-13)
        s = solve_fixed(m.rhs, (0, .05), [0, 0], 8, "implicit_euler", m.jac)
        x = (s.y-m.steady) * np.array([m.ld, m.lq])
        V = .5*np.sum(x*x, axis=1)
        rhs = -np.diff(s.t)*m.resistance*(x[1:,0]**2/m.ld+x[1:,1]**2/m.lq)-.5*np.sum(np.diff(x,axis=0)**2,axis=1)
        np.testing.assert_allclose(np.diff(V), rhs, atol=1e-17)
        self.assertTrue(np.all(np.diff(V) <= 0))

    def test_euler_spectral_stability_does_not_imply_contraction(self):
        m = PMSM()
        D = np.diag([m.ld, m.lq])
        B = D @ m.A @ np.diag([1/m.ld, 1/m.lq])
        M = np.eye(2)+.00072*B
        self.assertLess(max(abs(np.linalg.eigvals(M))),1.)
        self.assertGreater(max(np.linalg.eigvalsh(M.T@M)),1.)


if __name__ == "__main__":
    unittest.main(verbosity=2)
