# PMSM electrical IVP: reproducible numerical experiments

This is the executable numerical library accompanying the English Project 1 report. It models the current response to specified d- and q-axis voltages at an externally maintained rotor speed. The principal example uses **illustrative parameters**, not measured data. A separate replay checks previously saved **Simulink simulation outputs**, not hardware measurements.

## Quick start

Tested with Python 3.12.14. From the extracted submission folder containing `code/`:

```text
python -m pip install -r code/requirements.txt
python code/run_all.py
```

Alternatively, inside `code/`, run `python run_all.py`. No MATLAB, LaTeX installation, online service, absolute input path, or private credentials are needed. The script resolves its input/output paths relative to itself and overwrites only its generated figures and results. A complete run took approximately one minute on the development machine; timing depends on hardware. The animation is intentionally included in the full reproduction command.

For just the core numerical tests:

```text
python -m unittest discover -s code -p test_numerics.py -v
```

Dependencies are pinned to the versions actually tested. All core experiments are deterministic; no random numbers are used. Small last-digit differences across linear-algebra implementations are expected. The script stops if a test fails, the independent reference discrepancy exceeds 1e-9 A, the selected adaptive run exceeds its separately specified global target of 1e-5 A, or the saved simulation CSV fails its provenance hash check.

## Files and numerical choices

- `model.py`: parameter validation, PMSM RHS and Jacobian, equilibrium, matrix-exponential reference, torque, physical magnetic energy and the separate flux-error Lyapunov function.
- `integrators.py`: model-agnostic explicit Euler, classical RK4, implicit Euler with damped Newton, central-difference Jacobian fallback, and adaptive RK4 step doubling. Newton uses `numpy.linalg.solve`, with residual tolerances, an iteration limit and explicit line-search/singular-matrix failures. The finite-difference option makes the solver usable when a Jacobian is unavailable.
- `test_numerics.py`: eleven tests covering a zero-speed analytic limit; solution shape and accuracy; orders on a nonautonomous ODE; nonlinear Newton convergence, damping and failure; adaptive rejection, changing steps, accuracy and failures; finite-difference Jacobian checks; physical/discrete energy identities; and the distinction between spectral stability and norm contraction.
- `run_all.py`: all principal experiments, CSV tables, PNG/PDF figures, the GIF and `results/summary.json`.
- `build_report_results.py`: formats the computed results into `report/numerical_results.tex` and `report/existing_model_results.tex`; called after numerical results are finalized. It contains no solver logic.
- `existing_model_check.py`: separate replay of saved simulation signals, using both linearly interpolated and left-held inputs. Refinement and an exact constant-input check separate integration error from model/data mismatch.
- `data/existing_model_simulation.csv`: the six needed columns from the previously saved simulation, with no hardware data.
- `data/existing_model_metadata.json`: units, model parameters, transformations and SHA-256 provenance. The original simulation files are not needed to run the included replay.

The three required integrators and Newton iteration are implemented directly, so their stages and stopping rules can be inspected and modified. NumPy supplies vector arithmetic and linear solves. SciPy `expm` supplies the exact linear-system oracle; independently, `solve_ivp(method="Radau", rtol=1e-12, atol=1e-14)` validates the trajectory. SciPy root finding locates RK4's positive stability boundary; generalized symmetric eigenvalues locate the all-state flux-contraction threshold. These library calls are explicitly validation/linear-algebra tools, not substitutes for the implemented integrators.

## Model and conventions

The amplitude-invariant dq convention is used. SI parameters are `Rs=0.5 ohm`, `Ld=0.004 H`, `Lq=0.006 H`, `psi_f=0.08 Wb`, four pole pairs, `omega_e=500 rad/s`, `ud=0 V`, `uq=50 V`. The initial current is `(0,0) A`, and the main interval is `[0,0.05] s`. The rotor speed is an imposed input, not a solved mechanical state. The model omits inverter switching, current control, saturation, temperature dependence and spatial harmonics.

```text
di_d/dt = (u_d - Rs*i_d + omega_e*Lq*i_q)/Ld
di_q/dt = (u_q - Rs*i_q - omega_e*(Ld*i_d + psi_f))/Lq
T_e = 1.5*p*(psi_f*i_q + (Ld-Lq)*i_d*i_q)
```

This baseline is a non-stiff oscillatory system: its eigenvalue-modulus ratio is one. A severe explicit-Euler step restriction at high speed does not establish stiffness. Physical magnetic energy is `Wm=0.75*(Ld*i_d^2+Lq*i_q^2)` in joules. The decreasing error quantity is instead `V=0.5*((Ld*e_d)^2+(Lq*e_q)^2)` in squared webers, where `e=i-i_ss`. Confusing those quantities would give an incorrect saliency argument.

## How errors and tolerances are interpreted

Fixed-step convergence uses the maximum Euclidean current error at every method's own nodes on `[0,0.05] s`. Five mesh widths from 100 to 6.25 microseconds are used; the finest four give an asymptotic log-log least-squares fit. The shaded 95% bands describe deterministic regression residuals, not repeated-sample statistical uncertainty or a proof of the order.

Adaptive RK4 accepts the two-half-step value, without Richardson extrapolation. The local estimate is `(fine-coarse)/15`, scaled componentwise by `atol + rtol*max(abs(old),abs(fine))`, then combined by RMS. A trial is accepted when this ratio is at most one; the controller uses exponent `1/5`, safety factor 0.9 and bounded changes. The initial trial is 5 ms. Rejected trials are counted and shown. The last accepted step can be shorter simply to reach the final time.

**A local tolerance is not a global error guarantee.** The selected run uses `atol=1e-7 A`, `rtol=1e-7` and separately verifies a global engineering target of maximum current error <=1e-5 A against the exact reference. The local estimator is also compared with the exact one-step error from each accepted state. The tolerance sweep reports local ratios, actual global errors, cost and the global scaled error, including cases where the latter exceeds one.

The stability-region overlays are exact diagnostics for this constant linear system. For a nonlinear or time-varying model, an eigenvalue overlay is only a frozen-Jacobian diagnostic, not a general stability proof. Perturbation experiments test both sides of the predicted Euler and RK4 thresholds. A separate experiment shows a stable Euler step can increase the flux norm for one step: all-state monotone contraction is stricter than spectral stability.

## Generated outputs

Every principal figure is saved as both 240-dpi PNG and vector PDF in `figures/`:

1. `fig01_transient`: currents at h=0.5 ms, torque and dq phase trajectory.
2. `fig02_convergence`: all three methods, theoretical slopes and deterministic fit bands.
3. `fig03_stability_regions`: derived stability regions and h-lambda overlays.
4. `fig04_stability_test`: below/above-threshold perturbation experiments.
5. `fig05_adaptivity`: step changes, rejected trials, estimated/exact local error and global error.
6. `fig06_tolerance_sweep`: measured global error and work as tolerance changes.
7. `fig07_energy`: flux-error contraction and physical power balance.
8. `fig08_speed_comparison`: speed 0, 500 and 1500 rad/s, keeping `uq-omega_e*psi_f=10 V`.
9. `fig09_speed_restrictions`: stability thresholds and high-speed asymptotes.
10. `fig10_sensitivity`: steady-state elasticities, using central +/-1% parameter perturbations at fixed voltage and speed.
11. `fig11_contractivity`: spectral stability versus monotonic flux contraction.

`dq_phase.gif` animates the baseline current trajectory. `existing_model_validation.png` shows the separate previous-simulation replay, including the mismatch that persists after refinement. Its interpretation is conditional on the recorded voltage convention and saved model parameters.

`results/summary.json` contains all baseline numerical claims; CSV tables retain convergence, adaptive, energy-related trajectory, speed and sensitivity values. `results/test_results.txt` records the executable tests. `results/existing_model_summary.json` records the independent saved-simulation replay and provenance. No failed replay-to-simulation match is hidden or reclassified as numerical convergence.

## Academic use

This package was developed with AI assistance. It contains no invented student identity, human code-review signature, meeting record, commit history or individual contribution claim. The report's AI log and individual contribution records must reflect what the students actually did. Each presenting student should be able to derive the equations, explain the solver stages and error controller, rerun the experiments and discuss the unresolved simulation replay mismatch.
