"""Model-agnostic IVP solvers; all errors and Newton failures are explicit."""
from dataclasses import dataclass, field
import numpy as np


class NewtonFailure(RuntimeError):
    """An implicit step could not satisfy its stated residual criterion."""


@dataclass
class Solution:
    t: np.ndarray
    y: np.ndarray  # shape (number of saved times, number of states)
    stats: dict = field(default_factory=dict)


def _initial(t_span, y0):
    t0, tf = map(float, t_span)
    y = np.atleast_1d(np.asarray(y0, dtype=float)).copy()
    if not (np.isfinite([t0, tf]).all() and tf > t0):
        raise ValueError("t_span must contain finite, strictly increasing times")
    if y.ndim != 1 or not y.size or not np.isfinite(y).all():
        raise ValueError("y0 must be a nonempty finite vector")
    return t0, tf, y


def euler_step(f, t, y, h):
    return y + h * f(t, y)


def rk4_step(f, t, y, h):
    k1 = f(t, y)
    k2 = f(t + h / 2, y + h * k1 / 2)
    k3 = f(t + h / 2, y + h * k2 / 2)
    k4 = f(t + h, y + h * k3)
    return y + h * (k1 + 2 * k2 + 2 * k3 + k4) / 6


def finite_difference_jacobian(f, t, y):
    """Central differences with a component-scaled cube-root-epsilon step."""
    jac = np.empty((y.size, y.size))
    for j in range(y.size):
        delta = np.cbrt(np.finfo(float).eps) * max(1.0, abs(y[j]))
        yp, ym = y.copy(), y.copy()
        yp[j] += delta
        ym[j] -= delta
        jac[:, j] = (f(t, yp) - f(t, ym)) / (2 * delta)
    return jac


def implicit_euler_step(f, jac, t, y, h, *, atol=1e-11,
                        rtol=1e-11, max_iter=20):
    """Damped Newton for F(w)=w-y-h f(t+h,w); no explicit matrix inverse."""
    if atol <= 0 or rtol < 0 or max_iter < 1:
        raise ValueError("invalid Newton tolerances or iteration limit")
    w = y.copy()  # conservative predictor also works for stiff scalar tests
    residuals, damping = [], []
    for iteration in range(max_iter + 1):
        F = w - y - h * f(t + h, w)
        residual = float(np.linalg.norm(F, np.inf))
        residuals.append(residual)
        target = atol + rtol * max(np.linalg.norm(w, np.inf),
                                   np.linalg.norm(y, np.inf))
        if np.isfinite(residual) and residual <= target:
            return w, {"iterations": iteration, "residuals": residuals,
                       "damping": damping, "final_target": float(target)}
        if iteration == max_iter or not np.isfinite(residual):
            raise NewtonFailure(f"Newton failed at t={t+h:g}: residual={residual:g}")
        Jf = jac(t + h, w) if jac else finite_difference_jacobian(f, t + h, w)
        try:
            delta = np.linalg.solve(np.eye(y.size) - h * Jf, -F)
        except np.linalg.LinAlgError as exc:
            raise NewtonFailure(f"singular Newton matrix at t={t+h:g}") from exc
        alpha = 1.0
        while alpha >= 2 ** -20:
            candidate = w + alpha * delta
            Fc = candidate - y - h * f(t + h, candidate)
            if np.isfinite(Fc).all() and np.linalg.norm(Fc, np.inf) <= (1 - 1e-4 * alpha) * residual:
                w = candidate
                damping.append(alpha)
                break
            alpha *= 0.5
        else:
            raise NewtonFailure(f"Newton line search failed at t={t+h:g}")


def solve_fixed(f, t_span, y0, n_steps, method="rk4", jac=None, **newton_options):
    """Use n_steps equal steps, ending exactly at t_span[1]."""
    t0, tf, y0 = _initial(t_span, y0)
    if isinstance(n_steps, bool) or int(n_steps) != n_steps or n_steps <= 0:
        raise ValueError("n_steps must be a positive integer")
    if method not in ("euler", "rk4", "implicit_euler"):
        raise ValueError("unknown fixed-step method")
    t = np.linspace(t0, tf, int(n_steps) + 1)
    y = np.empty((t.size, y0.size))
    y[0] = y0
    stats = {"steps": int(n_steps), "rhs_evaluations": 0,
             "newton_iterations": 0, "newton_max_residual": 0.0}

    def counted(ti, yi):
        stats["rhs_evaluations"] += 1
        value = np.asarray(f(ti, yi), dtype=float)
        if value.shape != yi.shape:
            raise ValueError("RHS shape must match state shape")
        return value

    for n in range(int(n_steps)):
        h = t[n + 1] - t[n]
        if method == "implicit_euler":
            y[n + 1], diag = implicit_euler_step(counted, jac, t[n], y[n], h,
                                                **newton_options)
            stats["newton_iterations"] += diag["iterations"]
            stats["newton_max_residual"] = max(stats["newton_max_residual"], diag["residuals"][-1])
        else:
            step = euler_step if method == "euler" else rk4_step
            y[n + 1] = step(counted, t[n], y[n], h)
        if not np.isfinite(y[n + 1]).all():
            raise FloatingPointError(f"nonfinite state at step {n+1}")
    return Solution(t, y, stats)


def solve_adaptive_rk4(f, t_span, y0, *, atol=1e-7, rtol=1e-7,
                        h0=0.005, h_min=1e-14, h_max=np.inf,
                        max_steps=100000):
    """Step doubling, accepting the two-half-step result (not extrapolated).

    The fine-step local error estimate is (y_fine-y_coarse)/15. The RMS
    scaled estimate is accepted when <=1. Local control is not a theorem
    that the final global error is <= atol or rtol.
    """
    t0, tf, y = _initial(t_span, y0)
    atol = np.broadcast_to(np.asarray(atol, float), y.shape)
    if (not np.isfinite(atol).all() or np.any(atol <= 0) or
        not np.isfinite(rtol) or rtol < 0 or not np.isfinite(h0) or h0 <= 0 or
        not np.isfinite(h_min) or h_min <= 0 or np.isnan(h_max) or h_max < h_min or max_steps < 1):
        raise ValueError("invalid adaptive tolerance, step bound, or limit")
    times, values, accepted_h, error_ratios, rejected = [t0], [y.copy()], [], [], []
    t, h, nfev = t0, min(h0, h_max), 0

    def counted(ti, yi):
        nonlocal nfev
        nfev += 1
        value = np.asarray(f(ti, yi), float)
        if value.shape != yi.shape:
            raise ValueError("RHS shape must match state shape")
        return value

    for _ in range(max_steps):
        h = min(h, h_max, tf - t)
        if h < h_min or t + h == t:
            raise RuntimeError("adaptive step underflow before endpoint")
        coarse = rk4_step(counted, t, y, h)
        half = rk4_step(counted, t, y, h / 2)
        fine = rk4_step(counted, t + h / 2, half, h / 2)
        scale = atol + rtol * np.maximum(np.abs(y), np.abs(fine))
        ratio = float(np.sqrt(np.mean(((fine - coarse) / (15 * scale)) ** 2)))
        if not np.isfinite(ratio):
            ratio = np.inf
        if ratio <= 1:
            t = tf if h >= tf - t else t + h
            y = fine
            times.append(t)
            values.append(y.copy())
            accepted_h.append(h)
            error_ratios.append(ratio)
            if t == tf:
                break
            factor = 5.0 if ratio == 0 else np.clip(0.9 * ratio ** -0.2, 0.2, 5.0)
        else:
            rejected.append({"t": t, "h": h, "ratio": ratio})
            factor = np.clip(0.9 * ratio ** -0.2, 0.1, 0.5)
        h *= factor
    else:
        raise RuntimeError("adaptive attempt limit exceeded")
    return Solution(np.array(times), np.array(values),
                    {"steps": len(accepted_h), "rejections": len(rejected),
                     "rhs_evaluations": nfev, "accepted_h": accepted_h,
                     "error_ratios": error_ratios, "rejected_trials": rejected})
