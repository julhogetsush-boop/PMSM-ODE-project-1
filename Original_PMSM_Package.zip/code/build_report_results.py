"""Regenerate the report's numerical results from the executed experiment summaries."""
from pathlib import Path
import json

BASE = Path(__file__).resolve().parent
REPORT = BASE.parent / 'report'

def sci(x, digits=3):
    if x == 0:
        return '0'
    a, b = f'{x:.{digits}e}'.split('e')
    return rf'{a}\times10^{{{int(b)}}}'

def figure(name, caption, label, width='.97'):
    return (r'\begin{figure}[H]\centering'+'\n'+
            rf'\includegraphics[width={width}\textwidth]{{{name}}}'+'\n'+
            rf'\caption{{{caption}}}\label{{{label}}}'+'\n'+r'\end{figure}'+'\n')

def table(header, rows, spec, caption, label):
    return '\n'.join([r'\begin{table}[H]\centering\small',rf'\caption{{{caption}}}\label{{{label}}}',
        rf'\begin{{tabular}}{{{spec}}}\toprule',' & '.join(header)+r'\\\midrule',
        *[' & '.join(map(str,row))+r'\\' for row in rows],r'\bottomrule\end{tabular}\end{table}'])+'\n'

def main():
    s=json.loads((BASE/'results'/'summary.json').read_text())
    ex=json.loads((BASE/'results'/'existing_model_summary.json').read_text())
    REPORT.mkdir(exist_ok=True)
    pieces=[r'\subsection{Independent reference and observed order}',
      rf'The maximum Radau--matrix-exponential discrepancy is ${sci(s["validation"]["matrix_exponential_vs_Radau_max_error_A"])}$ A, below the $10^{{-8}}$ A check threshold. The Radau settings are $\mathrm{{rtol}}=10^{{-12}}$ and $\mathrm{{atol}}=10^{{-14}}$ A. The RHS and implicit-residual finite-difference Jacobian discrepancies are ${sci(s["validation"]["RHS_jacobian_fd_max_difference_per_s"])}\ \mathrm{{s^{{-1}}}}$ and ${sci(s["validation"]["implicit_residual_jacobian_fd_max_difference"])}$, respectively. These checks use different constructions of the same mathematical solution; they do not validate hardware parameters.',
      table([r'$h$ ($\mu$s)','Euler error (A)','RK4 error (A)','Implicit error (A)'],
       [[f'{h*1e6:g}']+['$'+sci(next(r['max_current_error_A'] for r in s['convergence']['rows'] if r['method']==m and r['h_s']==h))+'$' for m in ['euler','rk4','implicit_euler']] for h in [1e-4,5e-5,2.5e-5,1.25e-5,6.25e-6]],
       'rrrr',r'Maximum current-vector errors at each method\textquotesingle s own nodes over 0--50 ms. Every refinement halves the step. The exact matrix solution supplies the comparison.','tab:errors'),
      table(['Method','Expected order','Fitted order','Regression SE'],
       [[name,str(p),f"{s['convergence']['fits'][m]['order']:.5f}",f"{s['convergence']['fits'][m]['standard_error']:.5f}"] for m,name,p in [('euler','Euler',1),('rk4','RK4',4),('implicit_euler','Implicit Euler',1)]],
       'lrrr','Orders fitted on the same four finest meshes, 50 to 6.25 microseconds. SE quantifies the deterministic fit residual, not random experimental uncertainty.','tab:orders'),
      r'The fitted Euler and implicit-Euler orders lie on opposite sides of one because higher-order terms remain at finite step size. The fine-mesh error ratios move towards two. RK4 approaches order four, with its finest error small enough that floating-point accumulation and oracle evaluation can influence the final digits. The order fit is not a test that a narrow regression band must contain the theoretical order. No failed or unstable run is included in the convergence regression.',
      figure('fig02_convergence.pdf',r'All three convergence curves follow their theoretical power laws. The fitted bands are deterministic regression diagnostics; systematic curvature and the finest RK4 values explain small departures from exact integer slopes.','fig:order'),
      r'At $h=100\ \mu$s, Euler uses 500 RHS calls, RK4 uses 2000 and this implicit implementation uses 1500 plus 500 linear solves. RK4 achieves about $4.95\times10^{-7}$ A error while Euler and implicit Euler remain near 0.2 A. This comparison gives work and accuracy at a common step; it is not a matched-error efficiency benchmark. The first-order methods would need substantially more refinement for a small-current-error target.',
      r'\subsection{Voltage-step trajectory and physical outputs}',
      figure('fig01_transient.pdf',r'The exact solution exposes the coupled current oscillation and associated torque. The three numerical current traces use $h=0.5$ ms over the same interval, illustrating appreciable distortion despite spectral stability. Table~\ref{tab:errors} separately quantifies errors on the finer convergence meshes.','fig:transient'),
      rf'On the 25 microsecond diagnostic grid, the peak torque is {s["baseline"]["max_torque_Nm"]:.6f} N m at {s["baseline"]["max_torque_time_s"]*1000:.3f} ms, followed by a minimum of {s["baseline"]["min_torque_Nm"]:.6f} N m at {s["baseline"]["min_torque_time_s"]*1000:.3f} ms. The torque can briefly reverse under a fixed voltage while the current rotates through the coupled transient. The final current at 50 ms is $({s["baseline"]["final_current_A"][0]:.8f},{s["baseline"]["final_current_A"][1]:.8f})$ A. These extrema are sampled estimates, not root-refined peak times.',
      rf'The settling estimate is {s["baseline"]["flux_2percent_settling_time_s_grid_estimate"]*1000:.1f} ms, defined as the first diagnostic-grid time after which $\norm{{D(\ii-\ii_*)}}/\norm{{D(\ii(0)-\ii_*)}}$ stays below 0.02 through 50 ms. The continuous flux-norm contraction proves that the exact norm cannot later increase. A reproducible phase-plane animation, \texttt{{code/figures/dq\_phase.gif}}, makes the coupled transient visible without treating an animation as an error estimate.',
      r'\subsection{Experiments designed to make explicit methods fail}',
      figure('fig03_stability_regions.pdf',r'The shaded absolute-stability regions come from the three derived amplification functions. The actual complex PMSM eigenvalue products, rather than a negative-real approximation, locate the relevant stable and unstable steps.','fig:regions'),
      table(['Method','$h$ (ms)',r'$h/h_{\rm crit}$',r'$\rho(R)$','Final flux ratio'],
       [[{'euler':'Euler','rk4':'RK4'}[r['method']],f"{r['h_s']*1000:.6f}",f"{r['h_over_hcrit']:.4f}",f"{r['spectral_amplification']:.6f}",'$'+sci(r['final_flux_norm_ratio'])+'$'] for r in s['stability']['perturbations']],
       'lrrrr',r'Perturbation runs over 0.1 s. Ratios use the initial flux-error norm. Integer step counts slightly adjust the intended 0.8 and 1.2 multiples; the table reports actual steps.','tab:failure'),
      rf'The computed RK4 boundary is $h_4={s["stability"]["rk4_hcrit_s"]*1000:.9f}$ ms. Table~\ref{{tab:failure}} confirms decay below the spectral thresholds and growth above them. The deliberately unstable RK4 run grows by more than eight orders of magnitude in flux norm. The very small stable RK4 final ratio is not evidence of superior physical accuracy: a near-boundary step can overdamp the transient. The exact trajectory and fine-step convergence are still needed.',
      figure('fig04_stability_test.pdf',r'Perturbation integrations test the stability-region prediction directly. Above-threshold explicit steps amplify errors in a continuously contracting system. Below-threshold decay alone does not establish accurate damping or phase.','fig:failure'),
      r'\subsection{Contraction and power diagnostics}',
      rf'The all-state one-step Euler flux contraction threshold in \eqref{{eq:henergy}} is 0.640 ms, below the 0.800 ms asymptotic spectral threshold. Therefore a step in the interval $(0.640,0.800)$ ms can be stable in the long run and still increase the flux norm for a selected initial perturbation. This falsifies the stronger assertion that spectral stability guarantees monotone norm decay. The implicit-Euler discrete identity residual is ${sci(s["energy"]["max_implicit_discrete_identity_residual_Wb2"])}\ \mathrm{{Wb}}^2$.',
      figure('fig07_energy.pdf',r'The flux-error Lyapunov function and physical magnetic energy are distinct quantities. The flux bound and implicit-Euler decrease agree with the proof. The physical power terms illustrate the driven motor balance; its separately reported algebraic residual checks signs and factors, not independent trajectory accuracy.','fig:energy'),
      rf'The maximum algebraic physical-power residual is ${sci(s["energy"]["max_physical_power_residual_W"])}$ W. Because the derivative in this residual is evaluated from the same model RHS, this is an algebraic consistency test, not an independent test of time integration. The coarse implicit run uses $h={s["energy"]["coarse_implicit_h_s"]*1000:g}$ ms and one Newton correction per step; its stability at this step does not establish an accurate oscillatory waveform.',
      r'\subsection{A changing adaptive step and a separate global target}',
      table([r'Local $\mathrm{atol}=\mathrm{rtol}$','Accepted','Rejected','Max $E_n$','Global error (A)'],
       [['$'+sci(r['atol_A'],0)+'$',r['accepted_steps'],r['rejected_steps'],f"{r['max_local_scaled_error']:.3f}",'$'+sci(r['max_current_error_A'])+'$'] for r in s['adaptive']['rows']],
       'rrrrr',r'Local tolerance sweep. Atol has units A and rtol is dimensionless even when their numerical values are equal. Global error is measured independently by \eqref{eq:globalerror}.','tab:adaptive'),
      r'For a separately stated global engineering target $E_{\max}\leq10^{-5}$ A, the run with local $\mathrm{atol}=10^{-7}$ A and $\mathrm{rtol}=10^{-7}$ gives $E_{\max}=6.239\times10^{-6}$ A. It accepts 99 steps, rejects two trials and uses 1212 RHS evaluations. The accepted step range is 0.135793--0.915111 ms; the shortest step is clipped to the final time. The two rejected initial trials use 5 ms and 0.5 ms. The maximum accepted scaled estimate is 0.782626, close to but below the local acceptance boundary 1.',
      figure('fig05_adaptivity.pdf',r'The accepted time steps vary with transient difficulty and shrink at the terminal boundary. The independently computed current error stays below the stated $10^{-5}$ A global engineering target for the selected run. Acceptance still depends on the local scaled estimate.','fig:adaptive'),
      figure('fig06_tolerance_sweep.pdf',r'Tighter local tolerances decrease the measured global error and increase work. A scaled global error can exceed one while every accepted local ratio remains below one, demonstrating why the two tolerances must not be conflated.','fig:tols'),
      r'The largest global RMS error after scaling by the selected local tolerances is 26.23, so these data explicitly disprove a global guarantee at the local tolerance scale. The separate $10^{-5}$ A target is an observed bound for this trajectory, not a theorem for other inputs. Adaptivity is attractive here because the transient becomes easier as it decays; a fixed RK4 mesh is also effective when a uniform fine resolution is required.',
      r'\subsection{Speed and parameter sensitivity}',
      figure('fig08_speed_comparison.pdf',r'Keeping the effective $q$ excitation at 10 V separates rotational coupling from the back-EMF offset. The nonrotating case reduces to an $RL$ response; faster rotation changes the equilibrium and oscillation. These are ideal voltage-source simulations.','fig:speeds'),
      figure('fig09_speed_restrictions.pdf',r'The speed sweep supports the derived asymptotic slopes: Euler permits $O(\omega_e^{-2})$ steps, while RK4 permits $O(|\omega_e|^{-1})$ steps. Stability limits do not specify the steps needed to resolve a waveform accurately.','fig:speedlimits',width='.78'),
      r'To assess which parameters would matter in a later validation, the code also computes central finite-difference elasticities at fixed voltage and speed. For output $q$ and parameter $\theta$, the reported approximation is $(\theta/q_*)[q(1.01\theta)-q(0.99\theta)]/(0.02\theta)$. It is a local sensitivity, not an uncertainty interval or a parameter-identifiability proof.',
      figure('fig10_sensitivity.pdf',r'Local steady-state elasticities at fixed applied voltage show strong current sensitivity to permanent magnet flux in this operating condition, where the back EMF consumes most of the applied $q$ voltage. The bars use a symmetric 1\% parameter perturbation.','fig:sensitivity'),
      r'The current elasticities with respect to $\psi_f$ are approximately $-4$ on both axes, since a 1\% increase in $\psi_f$ raises the baseline back EMF by 0.4 V, a 4\% reduction in the 10 V effective drive. This gives a concrete reason to validate flux linkage and terminal voltage before interpreting small numerical differences as physical effects.'
    ]
    cp=BASE/'figures'/'fig11_contractivity.pdf'
    if cp.exists():
        location=pieces.index(r'\subsection{A changing adaptive step and a separate global target}')
        pieces.insert(location,figure('fig11_contractivity.pdf',r'A deliberately chosen perturbation distinguishes monotone flux contraction from eventual decay. The 0.640 ms contraction threshold is stricter than the 0.800 ms Euler spectral threshold.','fig:contractivity'))
    body='\n\n'.join(pieces)
    body=body.replace(r'10^{-8}', r'10^{-9}', 1)
    body=body.replace(r'$\norm{D(\ii-\ii_*)}/\norm{D(\ii(0)-\ii_*)}$', r'\[\norm{D(\ii-\ii_*)}/\norm{D(\ii(0)-\ii_*)}\]')
    body=body.replace(r'\texttt{code/figures/dq\_phase.gif}',r'\path{code/figures/dq_phase.gif}')
    local_audit=r'The selected adaptive controller was additionally checked against the exact one-step propagation from every accepted numerical state. The maximum actual local scaled error is 0.905483, and the actual-to-estimated local error ratio ranges from 0.838969 to 1.156980. This supports the estimator on the tested smooth trajectory while demonstrating that it is an approximation, not an exact local error formula.'
    body=body.replace(r'\subsection{Speed and parameter sensitivity}',local_audit+'\n\n'+r'\subsection{Speed and parameter sensitivity}')
    assert not any(ord(c)<32 and c!='\n' for c in body), 'Unexpected control character in generated LaTeX'
    (REPORT/'numerical_results.tex').write_text(body,encoding='utf-8')
    er=ex['linear_input_refined_RK4_vs_logged']; rfine=ex['RK4_h_over_8_vs_h_over_16']
    existing=[r'\subsection{Previously saved Simulink data as a falsification test}',
      r'A separate experiment replays a previously saved FOC/QEP simulation record. The source folder contains \texttt{mcb\_pmsm\_foc\_system.slx} and its logging/export workflow; the original model was not re-executed in this project. The supplied data copy contains 10,000 samples over 0--0.49995 s, after a 0.25 s warmup. The MAT metadata and CSV time column establish a 50 microsecond sample interval. An older README says 500 microseconds; the actual saved record is used. File provenance and SHA-256 hashes appear in \texttt{code/data/README.md} and the metadata file.',
      r'This recorded model has $R_s=0.36\ \Omega$, $L_d=L_q=0.0002$ H, $\psi_f=0.00639541518689$ Wb and $p=4$. It is a different parameter set from Table~\ref{tab:parameters}. The exported motor-terminal voltages subtract $R_{\rm board}i_d$ and $R_{\rm board}i_q$, with $R_{\rm board}=0.00433333333333\ \Omega$, from the logged controller voltages. Using those terminal voltages with motor-only $R_s$ avoids counting the board drop twice. A voltage file reconstructed from motor equations is not used as independent input evidence.',
      r'The replay starts once from the logged initial currents, $(0.0195680748,0.3652378446)$ A. It then integrates continuously using the recorded voltage and speed as externally prescribed inputs; it does not repeatedly reset the state to the logged currents. Linear interpolation of each input is performed separately on every 50 microsecond interval, with RK4 subdividing that interval. The refined reference uses 16 substeps per interval. A second comparison uses left-held inputs and an exact interval update; since $L_d=L_q$, each such update has a closed-form exponentially damped rotation. This separates solver refinement from input reconstruction sensitivity.',
      table(['Comparison','$i_d$ RMSE (A)','$i_q$ RMSE (A)','Max vector error (A)'],[
       ['Linear replay vs logs',f'{er["rms_axis_A"][0]:.6f}',f'{er["rms_axis_A"][1]:.6f}',f'{er["max_vector_norm_A"]:.6f}'],
       ['Left-held replay vs logs',f'{ex["left_held_input_exact_vs_logged"]["rms_axis_A"][0]:.6f}',f'{ex["left_held_input_exact_vs_logged"]["rms_axis_A"][1]:.6f}',f'{ex["left_held_input_exact_vs_logged"]["max_vector_norm_A"]:.6f}'],
       ['RK4 8 vs 16 substeps','$'+sci(rfine['rms_axis_A'][0])+'$','$'+sci(rfine['rms_axis_A'][1])+'$','$'+sci(rfine['max_vector_norm_A'])+'$']],
       'lrrr','The saved simulation currents disagree with the simple electrical replay far more than the numerical refinement discrepancy. These values are not hardware validation errors.','tab:existing'),
      figure('existing_model_validation.png',r'The earlier simulation export does not reproduce the simple voltage-driven ODE closely, especially on the $d$ axis. Refinement makes the replay numerically consistent while the log discrepancy persists. This is evidence against the assumed equivalence of the recorded signals and the simplified replay model.','fig:existing'),
      r'The logged $d$ current lies only between $-0.076997$ and $0.052660$ A, so a replay RMSE of 0.180625 A is substantial and cannot be described as a good match. Halving from 8 to 16 substeps changes the maximum current-vector result by only $2.7752\times10^{-10}$ A. Changing linear interpolation to a left hold changes the per-axis replay RMS by 0.002628 and 0.006165 A, which does not remove the main discrepancy. The evidence rules out RK4 step size as a plausible explanation for the large observed mismatch under these input reconstructions.',
      r'The cause remains unresolved. The next checks are the logged signal locations, Park angle and scaling, command-versus-applied voltage, and sample alignment. The terminal-voltage reconstruction shares logged currents, so even a successful replay would not have been completely independent physical validation. The result does not prove the existing Simulink motor is wrong. It shows that these saved signals, the stated constant parameters and the present input reconstruction are insufficient to claim agreement with this simplified IVP. Investigating that interface is more useful than hiding the mismatch or treating it as solver error.'
    ]
    (REPORT/'existing_model_results.tex').write_text('\n\n'.join(existing),encoding='utf-8')
    print('Regenerated report numerical sections from current summaries.')

if __name__=='__main__':
    main()
