"""Conditional electrical replay of a previously saved Simulink run.

The supplied signals are simulation outputs, not hardware measurements.
The replay uses known saved parameters; no parameter estimation is performed.
Input interpolation and temporal integration error are assessed separately.
"""
from pathlib import Path
import hashlib
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from integrators import rk4_step


def _metrics(value, reference):
    error = np.asarray(value) - np.asarray(reference)
    return {
        "rms_axis_A": np.sqrt(np.mean(error**2, axis=0)).tolist(),
        "max_abs_axis_A": np.max(np.abs(error), axis=0).tolist(),
        "max_vector_norm_A": float(np.max(np.linalg.norm(error, axis=1))),
    }


def replay_linear(t, signal, y0, parameters, subdivisions):
    """RK4 with every input knot exactly aligned; linear intersample inputs.

    signal columns are Ud, Uq, omega_e. At a knot the linear interpolant is
    continuous. Stage values are evaluated inside the current interval, so
    no step crosses a derivative discontinuity in the interpolated inputs.
    """
    R, Ld, Lq, psi = (parameters[k] for k in ("Rs", "Ld", "Lq", "FluxPM"))
    current = np.empty((len(t), 2))
    current[0] = y0
    for k, width in enumerate(np.diff(t)):
        start, increment = signal[k], signal[k+1] - signal[k]

        def f(local_t, y):
            ud, uq, omega = start + (local_t / width) * increment
            return np.array([(ud - R*y[0] + omega*Lq*y[1]) / Ld,
                             (uq - R*y[1] - omega*(Ld*y[0] + psi)) / Lq])

        y, h = current[k].copy(), width / subdivisions
        for j in range(subdivisions):
            y = rk4_step(f, j*h, y, h)
        current[k+1] = y
    return current


def replay_left_exact(t, signal, y0, parameters):
    """Exact per-interval propagation for the saved Ld=Lq surface PMSM.

    All three inputs are left-held. This is an alternative input model,
    not an independent exact solution for the linear-input replay.
    """
    R, Ld, Lq, psi = (parameters[k] for k in ("Rs", "Ld", "Lq", "FluxPM"))
    if not np.isclose(Ld, Lq, rtol=0, atol=1e-15):
        raise ValueError("analytic left-held replay requires Ld = Lq")
    current = np.empty((len(t), 2))
    current[0] = y0
    a = R / Ld
    for k, h in enumerate(np.diff(t)):
        ud, uq, omega = signal[k]
        b = np.array([ud/Ld, (uq-omega*psi)/Ld])
        # -A^{-1} b, with A = [[-a, omega], [-omega, -a]].
        equilibrium = np.array([a*b[0]+omega*b[1],
                                -omega*b[0]+a*b[1]]) / (a*a + omega*omega)
        c, s = np.cos(omega*h), np.sin(omega*h)
        rotation = np.array([[c, s], [-s, c]])
        current[k+1] = equilibrium + np.exp(-a*h)*rotation@(current[k]-equilibrium)
    return current


def run_existing_model_check(root):
    """Write figure/JSON below the code directory; return numerical results."""
    root = Path(root)
    data_dir = root / "data"
    raw_path = data_dir / "existing_model_simulation.csv"
    meta = json.loads((data_dir / "existing_model_metadata.json").read_text(encoding="utf-8"))
    actual_hash = hashlib.sha256(raw_path.read_bytes()).hexdigest()
    if actual_hash != meta["included_csv_sha256"]:
        raise ValueError("The simulation CSV differs from its recorded provenance hash")
    table = np.genfromtxt(raw_path, delimiter=",", names=True)
    t = table["time_s"]
    observed = np.column_stack((table["Id_A"], table["Iq_A"]))
    inputs = np.column_stack((table["Ud_motor_terminal_V"],
                              table["Uq_motor_terminal_V"], table["We_rad_s"]))
    assert len(t) == meta["samples"] and np.isfinite(inputs).all() and np.isfinite(observed).all()
    assert np.max(np.abs(np.diff(t)-meta["sample_time_s"])) < 1e-12
    parameters = meta["parameters"]
    # Independent exact constant-input check for the replay and sign convention.
    test_t = np.linspace(0, .001, 21)
    test_input = np.tile([1., 2., 300.], (len(test_t), 1))
    test_y0 = np.array([.2, .3])
    test_error = float(np.max(np.abs(
        replay_linear(test_t, test_input, test_y0, parameters, 4)
        - replay_left_exact(test_t, test_input, test_y0, parameters))))
    assert test_error < 1e-8, "Constant-input replay failed its exact check"
    runs = {n: replay_linear(t, inputs, observed[0], parameters, n)
            for n in (1, 2, 4, 8, 16)}
    reference = runs[16]
    left = replay_left_exact(t, inputs, observed[0], parameters)
    refinement = []
    for n in (1, 2, 4, 8):
        refinement.append({"subdivisions": n,
                           "h_s": meta["sample_time_s"] / n,
                           "error_vs_refined_replay": _metrics(runs[n], reference),
                           "error_vs_logged_simulation": _metrics(runs[n], observed)})
    hs = np.array([r["h_s"] for r in refinement])
    numerical = np.array([r["error_vs_refined_replay"]["max_vector_norm_A"] for r in refinement])
    coef, cov = np.polyfit(np.log(hs), np.log(numerical), 1, cov=True)

    # A trapezoidal integrated voltage-equation defect avoids claiming an
    # exact derivative of sampled currents. It includes sampling/hold error.
    R, Ld, Lq, psi = (parameters[k] for k in ("Rs", "Ld", "Lq", "FluxPM"))
    id_, iq = observed.T
    ud, uq, omega = inputs.T
    forcing = np.column_stack((ud-R*id_+omega*Lq*iq,
                               uq-R*iq-omega*(Ld*id_+psi)))
    residual_V = (np.diff(observed, axis=0)*np.array([Ld,Lq]) / np.diff(t)[:,None]
                  - (forcing[:-1] + forcing[1:])/2)
    summary = {
        "evidence_type": meta["evidence_type"],
        "data_sha256": actual_hash,
        "samples": len(t), "interval_s": [float(t[0]),float(t[-1])],
        "sample_time_s": meta["sample_time_s"],
        "parameters": parameters, "R_board_ohm": meta["R_board_ohm"],
        "initial_current_A": observed[0].tolist(),
        "constant_input_exact_check_max_abs_A": test_error,
        "logged_current_min_A": observed.min(axis=0).tolist(),
        "logged_current_max_A": observed.max(axis=0).tolist(),
        "electrical_speed_range_rad_s": [float(omega.min()),float(omega.max())],
        "voltage_range_V": [[float(ud.min()),float(ud.max())], [float(uq.min()),float(uq.max())]],
        "linear_input_refined_RK4_vs_logged": _metrics(reference, observed),
        "left_held_input_exact_vs_logged": _metrics(left, observed),
        "input_interpolation_sensitivity": _metrics(left, reference),
        "RK4_h_over_8_vs_h_over_16": _metrics(runs[8], reference),
        "refinement": refinement,
        "refinement_fit": {"slope": float(coef[0]),
                           "slope_standard_error": float(np.sqrt(cov[0,0])),
                           "meaning": "Deterministic log-log fit diagnostic against h/16 numerical reference; not a statistical confidence statement or rigorous error bound."},
        "trapezoidal_voltage_defect_RMS_V": np.sqrt(np.mean(residual_V**2,axis=0)).tolist(),
        "trapezoidal_voltage_defect_max_abs_V": np.max(np.abs(residual_V),axis=0).tolist(),
        "reference_definition": "RK4 with 16 steps per 50 us data interval, using linear input interpolation; h/8 agreement quantifies refinement evidence, not a rigorous error bound.",
        "scope": "Conditional electrical ODE replay from the initial logged currents and externally replayed voltage/speed. No repeated current resetting, parameter fitting, full closed-loop simulation or hardware validation.",
        "limitations": [
            "Motor-terminal voltage originally subtracts R_board times logged currents; data sources are partly shared.",
            "Sampled and interpolated logs cannot recover switching or true intersample input signals.",
            "The original MATLAB/Simulink model was not re-executed; comparison is against its previously saved outputs.",
            "A numerical mismatch plateau should not be attributed to RK4 discretization once the fine-step difference is much smaller."
        ],
    }
    for folder in (root/"results", root/"figures"):
        folder.mkdir(parents=True, exist_ok=True)
    (root/"results"/"existing_model_summary.json").write_text(
        json.dumps(summary, indent=2)+"\n", encoding="utf-8")

    with plt.rc_context({"font.size":9, "axes.spines.top":False,
                         "axes.spines.right":False, "figure.dpi":150}):
        fig, axes = plt.subplots(3, 2, figsize=(11.2, 9.2), constrained_layout=True)
        axes[0,0].plot(t, ud, label=r"$u_d$", color="#0072B2", lw=.8)
        axes[0,0].plot(t, uq, label=r"$u_q$", color="#D55E00", lw=.8)
        axes[0,0].set(ylabel="Motor-terminal voltage [V]",
                      title="Recorded voltage drives the replay")
        axes[0,1].plot(t,omega,color="#0072B2",label=r"Logged $\omega_e$",lw=.9)
        axes[0,1].set(ylabel="Electrical speed [rad/s]",
                      title="Speed is replayed as an external input")
        for j, label in enumerate((r"$i_d$",r"$i_q$")):
            ax=axes[1,j]
            ax.plot(t,observed[:,j],color="0.25",label="Saved Simulink output",lw=.9)
            ax.plot(t,reference[:,j],color="#0072B2",label="Linear-input RK4 replay",lw=.85,ls="--")
            ax.plot(t,left[:,j],color="#D55E00",label="Left-held exact replay",lw=.7,ls=":")
            ax.set(ylabel=f"{label} [A]",title=("d-axis discrepancy persists under refinement" if j==0
                                               else "q-axis transient envelope is reproduced approximately"))
        axes[2,0].plot(t,np.linalg.norm(reference-observed,axis=1),
                       label="Linear-input vs saved output",color="#0072B2",lw=.75)
        axes[2,0].plot(t,np.linalg.norm(left-observed,axis=1),
                       label="Left-held vs saved output",color="#D55E00",lw=.75,ls="--")
        axes[2,0].set(ylabel="Current error, Euclidean norm [A]",
                      title="The input-hold choice changes the discrepancy")
        logged = np.array([r["error_vs_logged_simulation"]["max_vector_norm_A"] for r in refinement])
        axes[2,1].loglog(hs,numerical,"o-",label="vs refined replay",color="#0072B2")
        axes[2,1].loglog(hs,logged,"s--",label="vs saved Simulink output",color="#D55E00")
        axes[2,1].loglog(hs,numerical[0]*(hs/hs[0])**4,":",color="0.35",label=r"$O(h^4)$ guide")
        lx=np.linspace(np.log(hs.min()),np.log(hs.max()),100)
        fitted=coef[0]*lx+coef[1]
        se=np.sqrt(np.maximum(0,cov[1,1]+2*lx*cov[0,1]+lx*lx*cov[0,0]))
        axes[2,1].fill_between(np.exp(lx),np.exp(fitted-1.96*se),np.exp(fitted+1.96*se),
                               color="0.4",alpha=.2,label="95% fit diagnostic band")
        axes[2,1].set(xlabel="RK4 substep h [s]",ylabel="Max current error norm [A]",
                      title="Refinement resolves integration, not missing inputs")
        for row in axes:
            for ax in row:
                ax.legend(fontsize=7,loc="best")
                ax.grid(alpha=.18)
                if ax is not axes[2,1]:
                    ax.set(xlabel="Time after logging start [s]",xlim=(t[0],t[-1]))
        fig.suptitle("Existing-model cross-check: saved simulation data, not hardware measurements",
                     fontsize=12,fontweight="bold")
        fig.savefig(root/"figures"/"existing_model_validation.png",dpi=220)
        plt.close(fig)
    print("Existing-model simulation replay: " + json.dumps({
        "linear_input_RMS_axis_A": summary["linear_input_refined_RK4_vs_logged"]["rms_axis_A"],
        "left_held_RMS_axis_A": summary["left_held_input_exact_vs_logged"]["rms_axis_A"],
        "fine_RK4_difference_A": summary["RK4_h_over_8_vs_h_over_16"]["max_vector_norm_A"]}))
    return summary


if __name__ == "__main__":
    run_existing_model_check(Path(__file__).resolve().parent)
