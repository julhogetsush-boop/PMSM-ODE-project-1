"""Constant-speed salient PMSM in the amplitude-invariant dq convention."""
from dataclasses import dataclass
import numpy as np
from scipy.linalg import expm


@dataclass(frozen=True)
class PMSM:
    """Illustrative SI parameters, not measured motor data."""
    resistance: float = 0.5  # ohm, phase resistance
    ld: float = 0.004  # H
    lq: float = 0.006  # H
    flux_pm: float = 0.08  # Wb, PM flux linkage
    pole_pairs: int = 4
    omega_e: float = 500.0  # rad/s, externally maintained
    ud: float = 0.0  # V
    uq: float = 50.0  # V

    def __post_init__(self):
        vals = [self.resistance, self.ld, self.lq, self.flux_pm, self.omega_e, self.ud, self.uq]
        if not np.isfinite(vals).all() or min(self.resistance, self.ld, self.lq) <= 0:
            raise ValueError("finite parameters with positive R, Ld and Lq required")
        if self.pole_pairs <= 0 or int(self.pole_pairs) != self.pole_pairs:
            raise ValueError("pole_pairs must be a positive integer")

    @property
    def A(self):
        return np.array([[-self.resistance / self.ld, self.omega_e * self.lq / self.ld],
                         [-self.omega_e * self.ld / self.lq, -self.resistance / self.lq]])

    @property
    def b(self):
        return np.array([self.ud / self.ld, (self.uq - self.omega_e * self.flux_pm) / self.lq])

    @property
    def steady(self):
        return np.linalg.solve(self.A, -self.b)

    def rhs(self, t, y):
        return self.A @ y + self.b

    def jac(self, t, y):
        return self.A

    def exact(self, t, y0=(0.0, 0.0)):
        """Matrix-exponential oracle, valid from initial time zero."""
        ti = np.atleast_1d(t)
        iss = self.steady
        out = np.array([iss + expm(self.A * float(s)) @ (np.asarray(y0) - iss) for s in ti])
        return out[0] if np.ndim(t) == 0 else out

    def torque(self, y):
        y = np.asarray(y)
        return 1.5 * self.pole_pairs * (self.flux_pm * y[..., 1] +
                                      (self.ld - self.lq) * y[..., 0] * y[..., 1])

    def magnetic_energy(self, y):
        y = np.asarray(y)
        return 0.75 * (self.ld * y[..., 0] ** 2 + self.lq * y[..., 1] ** 2)

    def flux_error_energy(self, y):
        """Lyapunov norm V in Wb^2; not physical magnetic energy in joules."""
        x = (np.asarray(y) - self.steady) * np.array([self.ld, self.lq])
        return 0.5 * np.sum(x * x, axis=-1)

    def power_terms(self, y):
        y = np.asarray(y)
        dy = y @ self.A.T + self.b
        p_in = 1.5 * (self.ud * y[..., 0] + self.uq * y[..., 1])
        p_cu = 1.5 * self.resistance * np.sum(y * y, axis=-1)
        p_mech = self.torque(y) * self.omega_e / self.pole_pairs
        dw = 1.5 * (self.ld * y[..., 0] * dy[..., 0] + self.lq * y[..., 1] * dy[..., 1])
        return p_in, p_cu, p_mech, dw
