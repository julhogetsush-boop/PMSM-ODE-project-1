# Existing-model simulation data

This is a six-column export from an existing, user-supplied local Simulink PMSM model run. **It is simulation data, not hardware measurements.** The original files were inspected read-only. Proprietary MATLAB/Simulink source is not redistributed.

`existing_model_simulation.csv` retains all 10,000 saved samples: time, d/q currents, motor-terminal d/q voltages, and electrical speed. The time interval is 0 to 0.49995 s with a 50 microsecond sample interval, following 0.25 s warmup. Currents/voltages/speed are in A/V/rad s^-1. Only columns were selected; no smoothing or parameter fitting was applied. Floating-point values were re-serialized with 17 significant digits.

`existing_model_metadata.json` records the source names, source SHA-256 hashes, included-data hash, extracted motor parameters, and voltage convention. Parameters were loaded specifically from the saved MAT file, not inferred from an example motor catalogue. The saved values and time stamps take precedence over an older README describing 500 microsecond sampling.

The motor-terminal voltages were originally computed by subtracting the known inverter-board resistance drop from the logged controller voltage using the logged currents. Consequently this is a conditional electrical-subsystem replay, with partial shared-data dependence. It is not an independent validation of the full controller, inverter, mechanical system or physical motor. Logged values were themselves sampled by the original script's linear interpolation; switching and intersample trajectories cannot be recovered from this CSV. The replay's linear-versus-left-held input comparison exposes that uncertainty.

No use is made of the separate `mcb_foc_qep_rls_input_from_motor_params.csv`, because reconstructed inputs would weaken an independent validation claim.
