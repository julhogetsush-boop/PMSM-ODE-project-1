# PMSM Project 1 submission package

This package contains an English mathematical report, reproducible Python experiments and presentation slides for the custom PMSM deterministic ODE pathway in the supplied Project 1 brief.

## Read first

- `report/report.pdf`: main LaTeX report, including model derivation, voltage/current response, stability proofs, numerical experiments, existing-simulation replay, hardware recommendations and AI transparency audits.
- `slides/PMSM_Project1_Presentation.pdf`: presentation PDF. The slides folder also contains the editable source and speaking notes.
- `assessment/Self_Assessment.pdf`: evidence-based rubric assessment and unresolved submission requirements.
- `code/README.md`: exact installation, reproduction and testing instructions.

The artifact review estimates **69/75 for dimensions A–E, equivalent to 92.0% after normalising only those dimensions**. This is not an official 92/100 project grade. Dimension F (25 points) requires real individual participation evidence, and oral presentation performance remains unobserved. At an eventual A–E subtotal of 69, an overall result strictly greater than 90 requires at least 22/25 in F. The instructor determines the actual marks.

## Before submission

Fill the true module code, team number, member names/IDs and presentation wave on the cover. Each member must replace their reserved ICS page with their own approximately 200-word contribution statement, genuine evidence and reflection, and complete their own ownership declaration. Supply the actual weekly tickets, challenge records, seminar peer reviews and existing Git evidence. The blank forms are not completed assessment evidence. Rehearse the 10-minute presentation and cross-role Q&A.

The supplied brief mentions `06_Templates/`, but that template was not among the eight files provided. The report uses a conventional A4 English LaTeX academic layout, a university-name cover, numbered equations/citations, captions and page numbers. It is adapted to the provided assignment requirements, not certified as the module's official template. If the module template is available, transfer the content into it before final submission. Official XJTLU teaching resources discuss multiple referencing conventions; this package does not claim a universal university font, margin or Harvard requirement.

## Reproduce

From this folder:

```text
python -m pip install -r code/requirements.txt
python code/run_all.py
```

This regenerates all report figures, the GIF, result tables and numerical LaTeX sections. The main report text remains editable in `report/report.tex`. Compile from its directory using `tectonic report.tex` or a normal LaTeX installation with `latexmk -pdf report.tex`. The report references the figures under `../code/figures/`; keep this folder structure. To update personal details, edit the cover and ICS entries in the main source and recompile.

The tested environment is Python 3.12.14 with the pinned versions in `code/requirements.txt`. No MATLAB installation is needed for the supplied numerical reproduction. All eleven main numerical tests passed during an independent complete rerun; the existing-data module also runs its own exact-case check and refinement study.

## Meaning of the datasets

The main benchmark uses illustrative salient-motor parameters chosen for a transparent, exactly solvable numerical experiment. It is not the parameter set of the earlier model.

The supplementary CSV is a minimal extract of previously saved Simulink output from the existing FOC/QEP model, using the parameters saved with that record. It is not hardware data. The replay gives a substantial d-axis discrepancy that persists under step refinement. It is included as a falsification result, with source hashes and the voltage reconstruction explained in `code/data/README.md`. The original model was read but not modified or executed. No proprietary MATLAB/Simulink model sources are redistributed.

Hardware collection is optional for the mathematical project. For motor validation, first audit the prior model's exported signal locations, timing and input reconstruction. Then collect an independently logged voltage/current transient with documented parameters and compare a separate test record, as described in the report.

## Authorship and records

These artefacts were produced with AI assistance. They contain no invented student signatures, attendance, Git commits, issue tickets or experimental measurements. The AI log records the mathematical verification and remaining limitations. Personal understanding and contributions must be established by the students themselves.
