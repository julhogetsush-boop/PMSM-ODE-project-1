"""Numerical time integrators for the PMSM IVP."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, Tuple

import numpy as np
from numpy.typing import ArrayLike, NDArray


RHS = Callable[[float, NDArray[np.float64]], NDArray[np.float64]]


@dataclass(frozen=True)
class SolverStats:
    steps: int
    f_evals: int
    rejected_steps: int = 0
    linear_solves: int = 0
    metadata: Dict[str, float] = field(default_factory=dict)


@dataclass(frozen=True)
class SolverResult:
    t: NDArray[np.float64]
    y: NDArray[np.float64]
    method: str
    stats: SolverStats


def _validate_span(t_span: Tuple[float, float], h: float) -> Tuple[float, float]:
    t0, t1 = map(float, t_span)
    if not np.isfinite([t0, t1, h]).all():
        raise ValueError("t0, t1 and h must be finite.")
    if t1 < t0:
        raise ValueError("t1 must be at least t0.")
    if h <= 0:
        raise ValueError("h must be positive.")
    return t0, t1


def _time_grid(t_span: Tuple[float, float], h: float) -> NDArray[np.float64]:
    t0, t1 = _validate_span(t_span, h)
    n_steps = int(np.ceil((t1 - t0) / h))
    t = np.empty(n_steps + 1, dtype=float)
    t[0] = t0
    for n in range(n_steps):
        t[n + 1] = min(t[n] + h, t1)
    return t


def explicit_euler(f: RHS, y0: ArrayLike, t_span: Tuple[float, float], h: float) -> SolverResult:
    """Solve y' = f(t, y) using explicit Euler."""
    t = _time_grid(t_span, h)
    y = np.empty((len(t),) + np.shape(y0), dtype=float)
    y[0] = np.asarray(y0, dtype=float)
    f_evals = 0

    for n in range(len(t) - 1):
        step = t[n + 1] - t[n]
        y[n + 1] = y[n] + step * f(t[n], y[n])
        f_evals += 1

    return SolverResult(t, y, "explicit_euler", SolverStats(len(t) - 1, f_evals))


def _rk4_step(f: RHS, t: float, y: NDArray[np.float64], h: float) -> NDArray[np.float64]:
    k1 = f(t, y)
    k2 = f(t + 0.5 * h, y + 0.5 * h * k1)
    k3 = f(t + 0.5 * h, y + 0.5 * h * k2)
    k4 = f(t + h, y + h * k3)
    return y + (h / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)


def rk4(f: RHS, y0: ArrayLike, t_span: Tuple[float, float], h: float) -> SolverResult:
    """Solve y' = f(t, y) using fixed-step classical RK4."""
    t = _time_grid(t_span, h)
    y = np.empty((len(t),) + np.shape(y0), dtype=float)
    y[0] = np.asarray(y0, dtype=float)

    for n in range(len(t) - 1):
        y[n + 1] = _rk4_step(f, t[n], y[n], t[n + 1] - t[n])

    steps = len(t) - 1
    return SolverResult(t, y, "rk4", SolverStats(steps, 4 * steps))


def implicit_euler_linear(
    A: ArrayLike,
    b: ArrayLike,
    y0: ArrayLike,
    t_span: Tuple[float, float],
    h: float,
) -> SolverResult:
    """Solve y' = A y + b using implicit Euler.

    Because the PMSM baseline model is linear with constant input, each
    implicit Euler step is one 2x2 linear solve:

        (I - h A) y_{n+1} = y_n + h b.
    """
    t = _time_grid(t_span, h)
    A = np.asarray(A, dtype=float)
    b = np.asarray(b, dtype=float)
    y = np.empty((len(t),) + np.shape(y0), dtype=float)
    y[0] = np.asarray(y0, dtype=float)

    for n in range(len(t) - 1):
        step = t[n + 1] - t[n]
        matrix = np.eye(A.shape[0]) - step * A
        y[n + 1] = np.linalg.solve(matrix, y[n] + step * b)

    steps = len(t) - 1
    return SolverResult(
        t,
        y,
        "implicit_euler_linear",
        SolverStats(steps, 0, linear_solves=steps),
    )


def adaptive_rk4(
    f: RHS,
    y0: ArrayLike,
    t_span: Tuple[float, float],
    h_initial: float,
    *,
    rtol: float = 1e-6,
    atol: float = 1e-9,
    h_min: float = 1e-8,
    h_max: float | None = None,
    safety: float = 0.9,
) -> SolverResult:
    """Adaptive RK4 using step doubling as the local error estimate."""
    t0, t1 = _validate_span(t_span, h_initial)
    if rtol <= 0 or atol < 0 or h_min <= 0:
        raise ValueError("rtol and h_min must be positive; atol must be nonnegative.")
    if h_max is not None and h_max <= 0:
        raise ValueError("h_max must be positive when provided.")

    y_current = np.asarray(y0, dtype=float)
    h = min(h_initial, t1 - t0) if h_max is None else min(h_initial, h_max, t1 - t0)
    t_values = [t0]
    y_values = [y_current.copy()]
    t_current = t0
    accepted = 0
    rejected = 0
    f_evals = 0

    while t_current < t1:
        h = min(h, t1 - t_current)
        if h < h_min:
            raise RuntimeError("adaptive RK4 reached h_min before completing the interval.")

        y_full = _rk4_step(f, t_current, y_current, h)
        y_half = _rk4_step(f, t_current, y_current, 0.5 * h)
        y_two_half = _rk4_step(f, t_current + 0.5 * h, y_half, 0.5 * h)
        f_evals += 12

        scale = atol + rtol * max(np.linalg.norm(y_current, ord=np.inf), np.linalg.norm(y_two_half, ord=np.inf))
        error = np.linalg.norm(y_two_half - y_full, ord=np.inf)

        if error <= scale:
            t_current += h
            y_current = y_two_half
            t_values.append(t_current)
            y_values.append(y_current.copy())
            accepted += 1

        if error == 0:
            factor = 2.0
        else:
            factor = safety * (scale / error) ** 0.2
            factor = min(2.0, max(0.2, factor))
        h *= factor
        if h_max is not None:
            h = min(h, h_max)
        if error > scale:
            rejected += 1

    return SolverResult(
        np.asarray(t_values),
        np.asarray(y_values),
        "adaptive_rk4",
        SolverStats(accepted, f_evals, rejected_steps=rejected),
    )
