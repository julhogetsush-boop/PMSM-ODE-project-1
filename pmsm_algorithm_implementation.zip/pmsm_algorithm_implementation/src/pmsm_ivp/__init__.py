"""PMSM ODE IVP model and numerical solvers."""

from .model import (
    DEFAULT_PARAMETERS,
    PMSMParameters,
    equilibrium,
    exact_solution,
    forcing_vector,
    jacobian,
    rhs,
)
from .solvers import (
    SolverResult,
    SolverStats,
    adaptive_rk4,
    explicit_euler,
    implicit_euler_linear,
    rk4,
)

__all__ = [
    "DEFAULT_PARAMETERS",
    "PMSMParameters",
    "SolverResult",
    "SolverStats",
    "adaptive_rk4",
    "equilibrium",
    "exact_solution",
    "explicit_euler",
    "forcing_vector",
    "implicit_euler_linear",
    "jacobian",
    "rhs",
    "rk4",
]
