"""Reproducible PMSM solver experiments."""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Dict

import matplotlib.pyplot as plt
import numpy as np

from .model import DEFAULT_PARAMETERS, equilibrium, exact_solution, forcing_vector, jacobian, rhs
from .solvers import adaptive_rk4, explicit_euler, implicit_euler_linear, rk4


def rk4_stability_function(z: complex | np.ndarray) -> complex | np.ndarray:
    return 1 + z + z**2 / 2 + z**3 / 6 + z**4 / 24


def explicit_euler_hmax(A: np.ndarray) -> float:
    """Return the largest h stable for all eigenvalues of A."""
    h_limits = []
    for lam in np.linalg.eigvals(A):
        if np.real(lam) >= 0:
            return 0.0
        h_limits.append(-2.0 * np.real(lam) / abs(lam) ** 2)
    return float(min(h_limits))


def rk4_hmax(A: np.ndarray, *, upper: float = 0.05) -> float:
    """Find the largest h such that every h*lambda lies in RK4's stability region."""
    eigvals = np.linalg.eigvals(A)

    def stable(h: float) -> bool:
        return bool(np.max(np.abs(rk4_stability_function(h * eigvals))) <= 1.0 + 1e-12)

    lo, hi = 0.0, upper
    while stable(hi):
        lo, hi = hi, 2 * hi
        if hi > 10.0:
            return float(lo)
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        if stable(mid):
            lo = mid
        else:
            hi = mid
    return float(lo)


def final_error(result, p=DEFAULT_PARAMETERS, y0=(0.0, 0.0)) -> float:
    reference = exact_solution(result.t[-1], y0, p)
    return float(np.linalg.norm(result.y[-1] - reference, ord=np.inf))


def observed_order(h_values: np.ndarray, errors: np.ndarray) -> float:
    """Fit log(error) = p log(h) + c and return p."""
    h_values = np.asarray(h_values, dtype=float)
    errors = np.asarray(errors, dtype=float)
    positive = errors > 0
    if np.count_nonzero(positive) < 2:
        return float("nan")
    slope, _ = np.polyfit(np.log(h_values[positive]), np.log(errors[positive]), 1)
    return float(slope)


def run_all(output_dir: Path) -> Dict[str, object]:
    """Run the main Algorithm implementation experiments and write outputs."""
    output_dir = Path(output_dir)
    figures_dir = output_dir / "figures"
    results_dir = output_dir / "results"
    figures_dir.mkdir(parents=True, exist_ok=True)
    results_dir.mkdir(parents=True, exist_ok=True)

    p = DEFAULT_PARAMETERS
    A = jacobian(p)
    b = forcing_vector(0.0, p)
    y0 = np.array([0.0, 0.0])
    t_span = (0.0, 0.05)
    f = lambda t, y: rhs(t, y, p)
    exact_dense_t = np.linspace(t_span[0], t_span[1], 1001)
    exact_dense_y = exact_solution(exact_dense_t, y0, p)

    h_plot = 1e-4
    euler_result = explicit_euler(f, y0, t_span, h_plot)
    rk4_result = rk4(f, y0, t_span, h_plot)
    implicit_result = implicit_euler_linear(A, b, y0, t_span, h_plot)
    adaptive_result = adaptive_rk4(f, y0, t_span, 1e-3, rtol=1e-7, atol=1e-10)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(exact_dense_t, exact_dense_y[:, 0], "k-", label="exact i_d")
    ax.plot(exact_dense_t, exact_dense_y[:, 1], "k--", label="exact i_q")
    ax.plot(rk4_result.t, rk4_result.y[:, 0], color="tab:blue", alpha=0.75, label="RK4 i_d")
    ax.plot(rk4_result.t, rk4_result.y[:, 1], color="tab:orange", alpha=0.75, label="RK4 i_q")
    ax.set_xlabel("t (s)")
    ax.set_ylabel("current (A)")
    ax.set_title("PMSM current trajectory")
    ax.grid(True, ls=":", alpha=0.6)
    ax.legend(ncol=2)
    fig.tight_layout()
    fig.savefig(figures_dir / "trajectory_comparison.png", dpi=160)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(exact_dense_y[:, 0], exact_dense_y[:, 1], "k-", label="exact")
    ax.plot(euler_result.y[:, 0], euler_result.y[:, 1], label="Euler")
    ax.plot(rk4_result.y[:, 0], rk4_result.y[:, 1], label="RK4")
    ax.scatter(*equilibrium(p), marker="x", color="red", label="equilibrium")
    ax.set_xlabel("i_d (A)")
    ax.set_ylabel("i_q (A)")
    ax.set_title("Phase plane")
    ax.grid(True, ls=":", alpha=0.6)
    ax.legend()
    fig.tight_layout()
    fig.savefig(figures_dir / "phase_plane.png", dpi=160)
    plt.close(fig)

    h_values = np.array([5e-5, 2.5e-5, 1.25e-5, 6.25e-6])
    method_errors = {"explicit_euler": [], "rk4": [], "implicit_euler": []}
    method_steps = {}
    for h in h_values:
        e = explicit_euler(f, y0, t_span, float(h))
        r = rk4(f, y0, t_span, float(h))
        im = implicit_euler_linear(A, b, y0, t_span, float(h))
        method_errors["explicit_euler"].append(final_error(e, p, y0))
        method_errors["rk4"].append(final_error(r, p, y0))
        method_errors["implicit_euler"].append(final_error(im, p, y0))
    for name in method_errors:
        method_errors[name] = np.asarray(method_errors[name])
    method_steps = {str(h): int(np.ceil((t_span[1] - t_span[0]) / h)) for h in h_values}
    observed_orders = {
        name: observed_order(h_values, errors)
        for name, errors in method_errors.items()
    }

    with (results_dir / "error_table.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["h", "explicit_euler_error", "rk4_error", "implicit_euler_error", "steps"])
        for idx, h in enumerate(h_values):
            writer.writerow([
                h,
                method_errors["explicit_euler"][idx],
                method_errors["rk4"][idx],
                method_errors["implicit_euler"][idx],
                method_steps[str(h)],
            ])

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.loglog(h_values, method_errors["explicit_euler"], "o-", label=f"Explicit Euler, order {observed_orders['explicit_euler']:.2f}")
    ax.loglog(h_values, method_errors["rk4"], "o-", label=f"RK4, order {observed_orders['rk4']:.2f}")
    ax.loglog(h_values, method_errors["implicit_euler"], "o-", label=f"Implicit Euler, order {observed_orders['implicit_euler']:.2f}")
    ax.invert_xaxis()
    ax.set_xlabel("step size h (s)")
    ax.set_ylabel("final-time infinity-norm error (A)")
    ax.set_title("Accuracy compared with exact solution")
    ax.grid(True, which="both", ls=":", alpha=0.6)
    ax.legend()
    fig.tight_layout()
    fig.savefig(figures_dir / "error_vs_step.png", dpi=160)
    plt.close(fig)

    h_explicit = explicit_euler_hmax(A)
    h_rk4 = rk4_hmax(A)
    eigvals = np.linalg.eigvals(A)
    h_scan = np.linspace(0.0, 1.35 * h_rk4, 600)
    euler_amp = np.max(np.abs(1 + h_scan[:, None] * eigvals[None, :]), axis=1)
    rk4_amp = np.max(np.abs(rk4_stability_function(h_scan[:, None] * eigvals[None, :])), axis=1)

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(h_scan, euler_amp, label="Explicit Euler amplification")
    ax.plot(h_scan, rk4_amp, label="RK4 amplification")
    ax.axhline(1.0, color="black", lw=1, ls="--")
    ax.axvline(h_explicit, color="tab:blue", lw=1, ls=":", label=f"Euler h_max={h_explicit:.2e}")
    ax.axvline(h_rk4, color="tab:orange", lw=1, ls=":", label=f"RK4 h_max={h_rk4:.2e}")
    ax.set_xlabel("step size h (s)")
    ax.set_ylabel("max |R(h lambda)|")
    ax.set_title("Linear stability along PMSM eigenvalues")
    ax.grid(True, ls=":", alpha=0.6)
    ax.legend()
    fig.tight_layout()
    fig.savefig(figures_dir / "stability_stepsize.png", dpi=160)
    plt.close(fig)

    step_sizes = np.diff(adaptive_result.t)
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.step(adaptive_result.t[:-1], step_sizes, where="post")
    ax.set_xlabel("t (s)")
    ax.set_ylabel("accepted h (s)")
    ax.set_title("Adaptive RK4 accepted step sizes")
    ax.grid(True, ls=":", alpha=0.6)
    fig.tight_layout()
    fig.savefig(figures_dir / "adaptive_steps.png", dpi=160)
    plt.close(fig)

    summary = {
        "parameters": {
            "Rs": p.Rs,
            "Ld": p.Ld,
            "Lq": p.Lq,
            "psi_f": p.psi_f,
            "omega_e": p.omega_e,
            "u_d": p.u_d,
            "u_q": p.u_q,
        },
        "A": A.tolist(),
        "b": b.tolist(),
        "equilibrium": equilibrium(p).tolist(),
        "eigenvalues": [[float(np.real(z)), float(np.imag(z))] for z in eigvals],
        "hmax": {
            "explicit_euler": h_explicit,
            "rk4": h_rk4,
            "implicit_euler": "A-stable for this left-half-plane linear system",
        },
        "final_errors_at_h_1e-4": {
            "explicit_euler": final_error(euler_result, p, y0),
            "rk4": final_error(rk4_result, p, y0),
            "implicit_euler": final_error(implicit_result, p, y0),
            "adaptive_rk4": final_error(adaptive_result, p, y0),
        },
        "stats_at_h_1e-4": {
            "explicit_euler": euler_result.stats.__dict__,
            "rk4": rk4_result.stats.__dict__,
            "implicit_euler": implicit_result.stats.__dict__,
            "adaptive_rk4": adaptive_result.stats.__dict__,
        },
        "error_sweep": {
            "h_values": h_values.tolist(),
            "errors": {name: values.tolist() for name, values in method_errors.items()},
            "observed_orders": observed_orders,
            "steps": method_steps,
        },
    }
    (results_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary
