import numpy as np

from pmsm_ivp.model import PMSMParameters, equilibrium, exact_solution, forcing_vector, jacobian, rhs


def test_default_matrix_and_forcing_match_derivation():
    A = jacobian()
    b = forcing_vector(0.0)
    expected_A = np.array([[-125.0, 750.0], [-1000.0 / 3.0, -250.0 / 3.0]])
    expected_b = np.array([0.0, 5000.0 / 3.0])
    assert np.allclose(A, expected_A)
    assert np.allclose(b, expected_b)


def test_equilibrium_matches_week1_derivation():
    assert np.allclose(equilibrium(), np.array([4.8, 0.8]))
    assert np.linalg.norm(rhs(0.0, equilibrium())) < 1e-10


def test_exact_solution_respects_initial_condition():
    y0 = np.array([0.2, -0.1])
    assert np.allclose(exact_solution(0.0, y0), y0)


def test_zero_speed_reduces_to_independent_rl_q_axis():
    p = PMSMParameters(omega_e=0.0)
    t = np.array([0.0, 0.01, 0.05])
    y = exact_solution(t, [0.0, 0.0], p)
    expected_i_d = np.zeros_like(t)
    expected_i_q = p.u_q / p.Rs * (1.0 - np.exp(-p.Rs * t / p.Lq))
    assert np.allclose(y[:, 0], expected_i_d)
    assert np.allclose(y[:, 1], expected_i_q)
