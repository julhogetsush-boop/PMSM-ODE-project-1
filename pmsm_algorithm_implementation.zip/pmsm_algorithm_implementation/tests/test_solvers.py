import numpy as np

from pmsm_ivp.experiments import explicit_euler_hmax, rk4_hmax
from pmsm_ivp.model import exact_solution, forcing_vector, jacobian, rhs
from pmsm_ivp.solvers import adaptive_rk4, explicit_euler, implicit_euler_linear, rk4


def test_rk4_is_more_accurate_than_explicit_euler_for_small_step():
    f = lambda t, y: rhs(t, y)
    y0 = np.array([0.0, 0.0])
    t_span = (0.0, 0.05)
    h = 1e-4
    euler = explicit_euler(f, y0, t_span, h)
    rk = rk4(f, y0, t_span, h)
    ref = exact_solution(t_span[1], y0)
    euler_error = np.linalg.norm(euler.y[-1] - ref, ord=np.inf)
    rk4_error = np.linalg.norm(rk.y[-1] - ref, ord=np.inf)
    assert rk4_error < euler_error
    assert rk4_error < 1e-7


def test_implicit_euler_linear_stays_finite_with_large_stable_step():
    A = jacobian()
    b = forcing_vector(0.0)
    y0 = np.array([0.0, 0.0])
    result = implicit_euler_linear(A, b, y0, (0.0, 0.05), 0.002)
    assert np.isfinite(result.y).all()
    assert result.stats.linear_solves == result.stats.steps


def test_adaptive_rk4_reaches_final_time_accurately():
    f = lambda t, y: rhs(t, y)
    y0 = np.array([0.0, 0.0])
    result = adaptive_rk4(f, y0, (0.0, 0.05), 1e-3, rtol=1e-7, atol=1e-10)
    ref = exact_solution(0.05, y0)
    assert np.isclose(result.t[-1], 0.05)
    assert np.linalg.norm(result.y[-1] - ref, ord=np.inf) < 1e-5
    assert result.stats.steps > 0


def test_stability_hmax_ordering():
    A = jacobian()
    assert explicit_euler_hmax(A) > 0
    assert rk4_hmax(A) > explicit_euler_hmax(A)
