# PMSM Algorithm Implementation

This folder contains Hannah's Algorithm implementation contribution for the PMSM ODE IVP project.

The model is the d-q electrical current IVP

```text
i'(t) = A i(t) + b(t),    i = [i_d, i_q].
```

Default Week 1 parameters give

```text
A = [[-125, 750],
     [-1000/3, -250/3]]
b = [0, 5000/3]
i_* = [4.8, 0.8]
```

The implemented numerical methods are:

- Explicit Euler
- Classical RK4
- Linear implicit Euler
- Adaptive RK4 using step doubling

## How to run

From this folder:

```powershell
python -m pip install -r requirements.txt
python .\scripts\run_experiments.py
python -m pytest
```

If the normal `python` command points to the unstable alpha Python on this computer, use the prepared course interpreter:

```powershell
C:\Users\Yolanda ZHANG\Documents\Codex\2026-09-08\new-chat\work\tools\Python313\python.exe .\scripts\run_experiments.py
C:\Users\Yolanda ZHANG\Documents\Codex\2026-09-08\new-chat\work\tools\Python313\python.exe -m pytest
```

## Reproducible outputs

Running `scripts/run_experiments.py` writes:

- `figures/trajectory_comparison.png`
- `figures/phase_plane.png`
- `figures/error_vs_step.png`
- `figures/stability_stepsize.png`
- `figures/adaptive_steps.png`
- `results/error_table.csv`
- `results/summary.json`

The error table also records the observed orders in `summary.json`.  In the
default run, Explicit Euler and Implicit Euler are close to first order, while
RK4 is close to fourth order.

## Notes for report

The baseline eigenvalues are a stable complex-conjugate pair, approximately

```text
-104.1667 +/- 499.5658 i
```

so the current trajectory is a damped oscillation toward the equilibrium. The stability experiment estimates method-dependent step-size limits from the eigenvalues:

- Explicit Euler is stable only while `max |1 + h lambda| <= 1`.
- RK4 allows a larger step, using its stability polynomial.
- Implicit Euler is A-stable for this left-half-plane linear system.
