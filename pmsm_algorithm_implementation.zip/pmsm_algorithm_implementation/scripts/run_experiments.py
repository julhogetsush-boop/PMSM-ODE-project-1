from pathlib import Path
import sys


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC = PROJECT_ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pmsm_ivp.experiments import run_all


def main() -> None:
    summary = run_all(PROJECT_ROOT)
    print("PMSM Algorithm implementation experiments complete.")
    print(f"Equilibrium: {summary['equilibrium']}")
    print(f"Explicit Euler h_max: {summary['hmax']['explicit_euler']:.6e}")
    print(f"RK4 h_max: {summary['hmax']['rk4']:.6e}")
    print("Figures written to ./figures")
    print("Summary written to ./results/summary.json")


if __name__ == "__main__":
    main()
